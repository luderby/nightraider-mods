﻿# Night Raider 刷新商店 + 物品底色 —— 一键卸载脚本
#
# 作用：把安装时备份的原始文件还原回去，等于「没装过 MOD」。
#   如果当初没装过别的 MOD（没有备份），则删除本包装进去的文件。

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

$pkgRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

function Say  ($m) { Write-Host $m }
function Ok   ($m) { Write-Host $m -ForegroundColor Green }
function Warn ($m) { Write-Host $m -ForegroundColor Yellow }
function Bad  ($m) { Write-Host $m -ForegroundColor Red }
function Line ()   { Write-Host ('-' * 62) -ForegroundColor DarkGray }

Say ''
Say '==============================================================' -ForegroundColor Cyan
Say '     Night Raider 刷新商店 + 物品底色   一键卸载' -ForegroundColor Cyan
Say '==============================================================' -ForegroundColor Cyan
Say ''
Warn '  ！卸载前请先完全退出游戏。'
Say ''
Read-Host '  按回车开始（直接关窗口=取消）'

function Test-GameDir([string]$p) {
    if ([string]::IsNullOrWhiteSpace($p)) { return $false }
    if (-not (Test-Path -LiteralPath $p)) { return $false }
    if (-not (Test-Path -LiteralPath (Join-Path $p 'NightRaider.exe'))) { return $false }
    if (-not (Test-Path -LiteralPath (Join-Path $p 'NightRaider_Data\Managed\Assembly-CSharp.dll'))) { return $false }
    return $true
}

# ---- 找游戏目录：先看安装时留下的记录，再退回到自动查找 ----
Line
Say '[1/2] 正在查找游戏目录 ...'

$game = $null
$record = Join-Path $pkgRoot '_上次安装的目录.txt'
if (Test-Path -LiteralPath $record) {
    $p = (Get-Content -LiteralPath $record -Raw).Trim()
    if (Test-GameDir $p) { $game = $p }
}

if (-not $game) {
    $steam = $null
    try { $steam = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -Name SteamPath -ErrorAction Stop).SteamPath } catch { }
    if ($steam) {
        $steam = $steam -replace '/', '\'
        $c = Join-Path $steam 'steamapps\common\Night Raider\NightRaider'
        if (Test-GameDir $c) { $game = $c }
        $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
        if (-not $game -and (Test-Path -LiteralPath $vdf)) {
            foreach ($m in [regex]::Matches((Get-Content -LiteralPath $vdf -Raw), '"path"\s+"(.+?)"')) {
                $lib = $m.Groups[1].Value -replace '\\\\', '\'
                $c2 = Join-Path $lib 'steamapps\common\Night Raider\NightRaider'
                if (Test-GameDir $c2) { $game = $c2; break }
            }
        }
    }
}

while (-not $game) {
    Say ''
    Say '  没找到游戏目录，请把游戏文件夹拖进本窗口后回车'
    Say '  （里面有 NightRaider.exe 的那一层）'
    Say ''
    $typed = Read-Host '  游戏目录'
    if ([string]::IsNullOrWhiteSpace($typed)) { continue }
    $typed = $typed.Trim().Trim('"').Trim()
    if (Test-GameDir $typed) { $game = (Resolve-Path -LiteralPath $typed).Path }
    else { Bad '  这不是 Night Raider 的游戏目录。' }
}
Ok ('  游戏目录：' + $game)

$running = @(Get-Process -Name 'NightRaider' -ErrorAction SilentlyContinue)
if ($running.Count -gt 0) {
    Bad '  游戏正在运行，请先完全退出再卸载。'
    Read-Host '  按回车退出'
    exit 1
}

# ---- 找最近的备份并还原 ----
Line
Say '[2/2] 正在还原 ...'

$backups = @(Get-ChildItem -LiteralPath $game -Directory -Filter '_MOD备份_*' -ErrorAction SilentlyContinue |
    Sort-Object Name -Descending)

if ($backups.Count -gt 0) {
    $b = $backups[0].FullName
    Say ('  使用备份：' + (Split-Path $b -Leaf))

    foreach ($f in 'winhttp.dll', 'doorstop_config.ini', '.doorstop_version') {
        $src = Join-Path $b $f
        if (Test-Path -LiteralPath $src) {
            Copy-Item -LiteralPath $src -Destination $game -Force
            Say ('  还原 ' + $f)
        }
    }
    $bep = Join-Path $b 'BepInEx'
    if (Test-Path -LiteralPath $bep) {
        $target = Join-Path $game 'BepInEx'
        if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
        Copy-Item -LiteralPath $bep -Destination $game -Recurse -Force
        Say '  还原 BepInEx\'
    }
    Ok '  已还原到安装前的状态。'
    Say ('  备份仍保留在：' + $b + '（确认没问题后可以自己删掉）')
}
else {
    Warn '  没有找到安装时的备份，改为直接删除本包装进去的文件。'
    foreach ($f in 'winhttp.dll', 'doorstop_config.ini', '.doorstop_version') {
        $t = Join-Path $game $f
        if (Test-Path -LiteralPath $t) { Remove-Item -LiteralPath $t -Force; Say ('  删除 ' + $f) }
    }
    $target = Join-Path $game 'BepInEx'
    if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force; Say '  删除 BepInEx\' }
    Ok '  已移除本包装的文件。'
    Say '  （如果这里本来还装过别的 MOD，它们也一起被删掉了，抱歉）'
}

Say ''
Read-Host '  按回车关闭'
