﻿# Night Raider 刷新商店 + 物品底色 v1.2 —— 一键安装脚本
#
# 设计目标：拿到压缩包 → 解压 → 双击「一键安装.bat」→ 其余全自动。
#   1) 自动定位游戏目录（注册表 → Steam 库文件 → 常见路径 → 手动拖文件夹）
#   2) 校验确实是 Night Raider 的目录，避免装错地方
#   3) 检查游戏是否在运行
#   4) 备份原有文件（可用「一键卸载.bat」还原）
#   5) 复制 BepInEx 运行库 + 2 个 MOD + 稀有度表
#
# 由「一键安装.bat」以 -ExecutionPolicy Bypass 调用，不依赖系统执行策略。
# 注意：本文件必须是「UTF-8 带 BOM」，否则 powershell.exe 会按 GBK 解码而报错。

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

$pkgRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

function Say  ($m) { Write-Host $m }
function Ok   ($m) { Write-Host $m -ForegroundColor Green }
function Warn ($m) { Write-Host $m -ForegroundColor Yellow }
function Bad  ($m) { Write-Host $m -ForegroundColor Red }
function Line ()   { Write-Host ('-' * 64) -ForegroundColor DarkGray }

Say ''
Say '==============================================================' -ForegroundColor Cyan
Say '     Night Raider 刷新商店 + 物品底色   v1.2   一键安装' -ForegroundColor Cyan
Say '     Refresh Shop  +  Item Rarity Tint  (BepInEx)' -ForegroundColor Cyan
Say '==============================================================' -ForegroundColor Cyan
Say ''
Say '  本程序会自动找到你的 Night Raider 游戏目录并安装这 2 个 MOD。'
Say '  不需要事先装过 BepInEx —— 运行库就在本包里。'
Say '  安装前会自动备份原有文件，可随时用「一键卸载.bat」还原。'
Say ''
Warn '  ！安装前请先完全退出游戏（Steam 里点“停止”）。'
Say ''
Read-Host '  准备好后按回车开始（直接关窗口 = 取消）'

# ---------------------------------------------------------------- 校验包完整
Line
Say '[1/5] 检查安装包是否完整 ...'

$mustHave = @(
    'winhttp.dll',
    'doorstop_config.ini',
    '.doorstop_version',
    'BepInEx\core\BepInEx.dll',
    'BepInEx\core\0Harmony.dll',
    'BepInEx\plugins\NightRaider.RareRefresh.dll',
    'BepInEx\plugins\NightRaider.RareTint.dll',
    'BepInEx\plugins\NightRaider_item_tiers.csv',
    'BepInEx\config\NightRaider_item_tiers.csv',
    'BepInEx\config\nightraider.rarerefresh.cfg',
    'BepInEx\config\nightraider.raretint.cfg'
)
$missing = @()
foreach ($f in $mustHave) {
    if (-not (Test-Path -LiteralPath (Join-Path $pkgRoot $f))) { $missing += $f }
}
if ($missing.Count -gt 0) {
    Bad '  安装包不完整，缺少以下文件：'
    foreach ($f in $missing) { Bad ('    ' + $f) }
    Say ''
    Warn '  请重新解压压缩包（不要只解压一部分文件），然后重试。'
    Say ''
    Read-Host '  按回车退出'
    exit 1
}
Ok '  安装包完整（刷新商店 + 物品底色，共 2 个 MOD）。'

# ---------------------------------------------------------------- 找游戏目录
Line
Say '[2/5] 正在自动查找游戏目录 ...'

function Test-GameDir([string]$p) {
    if ([string]::IsNullOrWhiteSpace($p)) { return $false }
    if (-not (Test-Path -LiteralPath $p)) { return $false }
    if (-not (Test-Path -LiteralPath (Join-Path $p 'NightRaider.exe'))) { return $false }
    # Unity 游戏本体的标志，用它确认没装错到别的同名文件夹
    if (-not (Test-Path -LiteralPath (Join-Path $p 'NightRaider_Data\Managed\Assembly-CSharp.dll'))) { return $false }
    return $true
}

$candidates = New-Object System.Collections.ArrayList

# a) Steam 安装位置（注册表）
$steam = $null
try { $steam = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -Name SteamPath -ErrorAction Stop).SteamPath } catch { }
if (-not $steam) {
    try { $steam = (Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam' -Name InstallPath -ErrorAction Stop).InstallPath } catch { }
}
if ($steam) {
    $steam = $steam -replace '/', '\'
    [void]$candidates.Add((Join-Path $steam 'steamapps\common\Night Raider\NightRaider'))

    # b) 其他 Steam 库（libraryfolders.vdf）
    $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
    if (Test-Path -LiteralPath $vdf) {
        try {
            $raw = Get-Content -LiteralPath $vdf -Raw
            foreach ($m in [regex]::Matches($raw, '"path"\s+"(.+?)"')) {
                $lib = $m.Groups[1].Value -replace '\\\\', '\'
                [void]$candidates.Add((Join-Path $lib 'steamapps\common\Night Raider\NightRaider'))
            }
        }
        catch { }
    }
}

# c) 各盘符的常见位置
$subs = @(
    'steamapps\common\Night Raider\NightRaider',
    'SteamLibrary\steamapps\common\Night Raider\NightRaider',
    'Steam\steamapps\common\Night Raider\NightRaider',
    'Program Files (x86)\Steam\steamapps\common\Night Raider\NightRaider',
    'Program Files\Steam\steamapps\common\Night Raider\NightRaider',
    'Games\Steam\steamapps\common\Night Raider\NightRaider'
)
foreach ($drv in (Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
    foreach ($s in $subs) {
        [void]$candidates.Add((Join-Path $drv.Root $s))
    }
}

$game = $null
foreach ($c in $candidates) {
    if (Test-GameDir $c) { $game = (Resolve-Path -LiteralPath $c).Path; break }
}

# d) 找不到就请用户手动给（支持把文件夹拖进窗口）
while (-not $game) {
    Say ''
    Warn '  没有自动找到游戏目录。'
    Say ''
    Say '  请手动指定：打开 Steam → 库 → 右键「Night Raider」→ 管理 → 浏览本地文件，'
    Say '  然后把打开的文件夹直接拖到这个窗口里，再按回车。'
    Say ''
    Say '  （要选的是里面有 NightRaider.exe 的那一层，通常是 ...\common\Night Raider\NightRaider）'
    Say ''
    $typed = Read-Host '  游戏目录'
    if ([string]::IsNullOrWhiteSpace($typed)) { continue }
    $typed = $typed.Trim().Trim('"').Trim()
    if (Test-GameDir $typed) {
        $game = (Resolve-Path -LiteralPath $typed).Path
    }
    else {
        Bad '  这个目录看起来不是 Night Raider 的游戏目录（没找到 NightRaider.exe）。'
        Say '  请再试一次，或关掉窗口取消安装。'
    }
}

Ok ('  已找到游戏目录：' + $game)

# 记下安装位置，供「一键卸载.bat」使用
try { Set-Content -LiteralPath (Join-Path $pkgRoot '_上次安装的目录.txt') -Value $game -Encoding UTF8 } catch { }

# ---------------------------------------------------------------- 游戏是否在跑
Line
Say '[3/5] 检查游戏是否正在运行 ...'

$running = @(Get-Process -Name 'NightRaider' -ErrorAction SilentlyContinue)
if ($running.Count -gt 0) {
    Bad '  检测到游戏正在运行！'
    Say ''
    Say '  请先完全退出游戏（Steam 里点“停止”，确认任务栏/托盘里也没有了），'
    Say '  然后重新运行本安装程序。'
    Say ''
    Read-Host '  按回车退出'
    exit 1
}
Ok '  游戏未运行，可以安全安装。'

# ---------------------------------------------------------------- 备份
Line
Say '[4/5] 备份原有文件 ...'

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backup = Join-Path $game ('_MOD备份_' + $stamp)
$hadAnything = $false

New-Item -ItemType Directory -Force -Path $backup | Out-Null

foreach ($f in 'winhttp.dll', 'doorstop_config.ini', '.doorstop_version') {
    $src = Join-Path $game $f
    if (Test-Path -LiteralPath $src) {
        Copy-Item -LiteralPath $src -Destination $backup -Force
        $hadAnything = $true
    }
}
$oldBep = Join-Path $game 'BepInEx'
if (Test-Path -LiteralPath $oldBep) {
    Copy-Item -LiteralPath $oldBep -Destination (Join-Path $backup 'BepInEx') -Recurse -Force
    $hadAnything = $true
}

if ($hadAnything) {
    Ok ('  原文件已备份到：' + $backup)
    Say '  （想还原就运行「一键卸载.bat」）'
}
else {
    Say '  之前没有装过 MOD，无需备份。'
    Remove-Item -LiteralPath $backup -Force -Recurse -ErrorAction SilentlyContinue
    $backup = $null
}

# ---------------------------------------------------------------- 复制
Line
Say '[5/5] 正在安装 ...'

foreach ($f in 'winhttp.dll', 'doorstop_config.ini', '.doorstop_version') {
    Copy-Item -LiteralPath (Join-Path $pkgRoot $f) -Destination $game -Force
    Say ('  + ' + $f)
}

Copy-Item -LiteralPath (Join-Path $pkgRoot 'BepInEx') -Destination $game -Recurse -Force
Say '  + BepInEx\  （运行库 + 刷新商店 + 物品底色 + 稀有度表 + 配置）'

# 本包不含「物品商店」，若旧版留下了就提醒一下
$oldShop = Join-Path $game 'BepInEx\plugins\NightRaider.RareShop.dll'
if (Test-Path -LiteralPath $oldShop) {
    Warn ''
    Warn '  提示：检测到 NightRaider.RareShop.dll（物品商店）。本包不包含它，'
    Warn '  本包不含 F8 商店功能。如果它来自你以前的安装且你不需要，删掉即可：'
    Warn ('    ' + $oldShop)
}

# ---------------------------------------------------------------- 校验
$checks = @(
    'winhttp.dll',
    'BepInEx\core\BepInEx.dll',
    'BepInEx\core\0Harmony.dll',
    'BepInEx\plugins\NightRaider.RareRefresh.dll',
    'BepInEx\plugins\NightRaider.RareTint.dll',
    'BepInEx\plugins\NightRaider_item_tiers.csv',
    'BepInEx\config\NightRaider_item_tiers.csv',
    'BepInEx\config\nightraider.rarerefresh.cfg',
    'BepInEx\config\nightraider.raretint.cfg'
)
$bad = @()
foreach ($f in $checks) {
    if (-not (Test-Path -LiteralPath (Join-Path $game $f))) { $bad += $f }
}

Line
if ($bad.Count -eq 0) {
    Ok '  安装完成，全部文件校验通过！'
}
else {
    Bad '  安装似乎不完整，缺少：'
    foreach ($f in $bad) { Bad ('    ' + $f) }
    Say '  请把以上内容截图反馈。'
}

Say ''
Say '==============================================================' -ForegroundColor Cyan
Say '  怎么用' -ForegroundColor Cyan
Say '==============================================================' -ForegroundColor Cyan
Say ''
Say '  1. 从 Steam 正常启动游戏，读取你的存档。'
Say '  2. 按  F7  打开「刷新商店」：'
Say '       10 张卡片，每张自己随机抽一个分类（共 11 个分类）：'
Say '         武器 / 配件 / 材料 / 装备 / 子弹 / 药品'
Say '         食物 / 投掷物 / 书籍 / 钥匙证件 / 收藏品'
Say '       价格按稀有度分级，可堆叠物品一次卖一整堆'
Say '       买完变「已售罄」，点下方「刷新」花 5 万 GP 整页重掷'
Say '  3. 按  F6  重新读取稀有度表（改完 CSV 用，平时不用管）。'
Say ''
Say '  物品底色 = 稀有度（背包、仓库、箱子、商店都会显示）：'
Say '       灰 = 普通    绿 = 优良    蓝 = 稀有'
Say '       紫 = 史诗    橙 = 传说    红 = 绝世'
Say '  鼠标悬停在物品上时，说明里的物品名也会是对应颜色。'
Say ''
Say '  打开背包界面时，人物身上穿的 9 个装备格子也会显示稀有度底色。'
Say '  两处快捷栏（HUD 6 格 + 背包界面 6 格）用「底边色条」表示稀有度，不挡图标；'
Say '  按 F1 隐藏快捷栏时色条一起隐藏，再按 F1 会一起恢复。'
Say ''
Say '  已锁定 / 已标记的格子不再变红/变金，改为悬停说明末尾显示「【已锁定】/【已标记】」。'
Say '  耐久归零的装备格子改为暗灰（不再是游戏的大红），悬停说明末尾显示「【已损坏】」。'
Say ''
Say '  打开武器的改装界面时，7 个配件槽和「选择配件」弹窗也会按稀有度上色；'
Say '  鼠标悬停在配件上，说明里的配件名同样是稀有度颜色。'
Say ''
Say '  注意事项：'
Say '     - 装之前请先备份存档；安装/卸载前必须先完全退出游戏。'
Say '     - 本包不含商店类 MOD；若你另装过别的商店，别和刷新商店同时开着。'
Say '     - 改完档位表 CSV 后要按 F6 重新读取。'
Say ''
Say '  想调设置：'
Say '       底色深浅、档位配色、锁定文字 → BepInEx\config\nightraider.raretint.cfg'
Say '       刷新费用 / 概率 / 价格倍率  → BepInEx\config\nightraider.rarerefresh.cfg'
Say '       改完按 F6 或重新开一次窗口即可生效，不必重启游戏。'
Say ''
if ($backup) {
    Say ('  想卸载：运行「一键卸载.bat」，或把 ' + (Split-Path $backup -Leaf) + ' 里的内容复制回游戏目录。')
}
Say ''
Ok '  现在可以从 Steam 启动游戏了。'
Say ''
Say '==============================================================' -ForegroundColor DarkGray
Say '  声明' -ForegroundColor DarkGray
Say '==============================================================' -ForegroundColor DarkGray
Write-Host '  本 Mod 用于个人娱乐使用，并进行免费的分享，' -ForegroundColor DarkGray
Write-Host '  但不对使用本作品可能导致的任何损害承担责任，包括但不限于：' -ForegroundColor DarkGray
Write-Host '  游戏存档损坏或丢失、游戏崩溃、与其他模组的兼容性问题、' -ForegroundColor DarkGray
Write-Host '  因游戏版本更新导致的模组失效。' -ForegroundColor DarkGray
Write-Host '  使用前请自行备份存档；安装即表示你已理解并接受上述说明。' -ForegroundColor DarkGray
Say ''
Read-Host '  按回车关闭'
