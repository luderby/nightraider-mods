# 构建说明（BUILD.md）

## 环境要求

- .NET SDK 9（已在本机验证：`C:\Program Files\dotnet\sdk\9.0.318`）
- 游戏本体（提供编译所需的 `Assembly-CSharp.dll`、`UnityEngine*.dll`）
- BepInEx 5.4.23.5 win_x64（已随包提供）

Mod 目标框架为 `netstandard2.1`：Unity 2022.3 的 `UnityEngine.CoreModule.dll` 依赖 netstandard 2.1，
所以不能用 netstandard2.0（会报 `CS1705`）。

## 项目结构

```
src/
├── RareShop.csproj     引用游戏 DLL + BepInEx，编译后自动复制到 BepInEx\plugins
├── Plugin.cs           BepInEx 入口、热键、配置、Harmony 补丁（窗口判定 + 输入屏蔽）
├── GameRefs.cs         安全获取游戏单例（关键：不能用 ManagerBase<T>.Instance）
├── Catalog.cs          商品目录构建、分类、无用物品过滤、售价换算
├── ShopPanel.cs        自绘商店 UI 与购买逻辑，行底色走稀有度调色板
├── UiFactory.cs        运行时创建 uGUI 控件的小工具
├── BagWriter.cs        往背包/仓库放物品的安全实现
├── ItemTiers.cs        (v1.3.0) 读 modelID → 档位 的 CSV 表，支持热重载
│                                 (v1.3.1) tier<=0 的行跳过（= "待定"，保留游戏原色）
├── RarityPalette.cs    (v1.3.0) 档位 → 名称/颜色，配置驱动
├── BagRarityPatch.cs   (v1.3.0) Harmony Postfix，给游戏自带背包格子上稀有度底色
├── TierTest/           (v1.3.0) 离线测试：把真实的 ItemTiers.cs 编进来跑真实 CSV
└── MetaCheck/          (v1.3.0) 离线校验：只读 Assembly-CSharp.dll 元数据，核对补丁目标
```

包根目录还有稀有度表的生成/合并脚本：

| 脚本 | 用途 |
|---|---|
| `make_tiers2.ps1` | 按**掉落机制**重新生成 `item_tiers.csv`（容器池阶梯 + 概率 + 装备/背包升级链），并写出待定清单 |
| `merge_pending.ps1` | 把人工填好的 `item_tiers_pending.csv` 合并回主表（自动识别 GBK/UTF-8） |
| `spawn_chance.ps1` | 算每件物品的掉落权重分布与「几率 vs 价格」秩相关 |
| `loot_chains.ps1` | 从 `BuildingControl.GetBagContent` 提取容器池阶梯与池名，验证解析正确性 |

生成规则与推导过程见 [ITEM_TIERS.md](ITEM_TIERS.md) 第 7 节。

## 编译

```powershell
cd src\RareShop
dotnet build -c Release
```

## 验证（都不需要启动游戏）

```powershell
# 1) CSV 解析器：把真实的 ItemTiers.cs 编进测试工程，断言 1373 行全部映射、无坏行
dotnet run --project src\TierTest -c Release -- `
  "NightRaider\BepInEx\config" `
  "_moddev\item_catalog.json"

# 2) 补丁目标：确认私有字段名在当前安装的 Assembly-CSharp.dll 里仍然存在
dotnet run --project src\MetaCheck -c Release -- `
  "NightRaider\NightRaider_Data\Managed\Assembly-CSharp.dll"
```

第 2 项很关键：`BagRarityPatch` 反射的是 `MyBagControl` 的**私有字段**
`myBag_GOBJ` / `targetBag_GOBJ`。游戏更新如果改了字段名，Mod 会**安静地**停止给背包上色
（只留一条 warning），这个检查能在启动游戏前发现。

`make_tiers.ps1` 用来重新生成稀有度草稿表（输出 `item_tiers.csv`），推导规则见
[ITEM_TIERS.md](ITEM_TIERS.md) 第 7 节。

`RareShop.csproj` 里的 `GameDir` 指向游戏目录，编译完成后会自动把
`NightRaider.RareShop.dll` 复制到 `$(GameDir)\BepInEx\plugins\`。

如果需要改路径，编辑 `RareShop.csproj`：

```xml
<GameDir>G:\steamruanjian\steamapps\common\Night Raider\NightRaider</GameDir>
```

## 编译注意（踩过的坑）

1. **目标框架必须是 netstandard2.1**，否则 `CS1705`。
2. **不要用 `ManagerBase<T>.Instance`**：它不会返回 null，而会凭空 new 一个
   GameObject 并把组件挂上去（`ManagerBase.cs:11-15`）。在游戏初始化之前调用它，
   会留下一个字段全是 null 的僵尸管理器。本项目统一走 `GameRefs`（内部用
   `FindObjectOfType`）。
3. 用脚本批量改 `.cs` 文件时**记得更新文件时间戳**，否则 MSBuild 会认为
   输出是最新的而跳过编译：

   ```powershell
   Get-ChildItem -Recurse src -Include *.cs | ForEach-Object { $_.LastWriteTime = Get-Date }
   dotnet build -c Release
   ```

4. 嵌套 Canvas **必须自带 `GraphicRaycaster`**：`GraphicRegistry` 按最近的
   Canvas 分组，父 Canvas 的 raycaster 看不到子 Canvas 的图形。
5. 字体不要用 `Resources.GetBuiltinResource<Font>("Arial.ttf")`（2022 里名字不对且无中文），
   本项目从场景里已有的 `Text` 组件借字体（游戏内嵌 **LanaPixel**，含中文）。
6. **页签枚举必须和 `TabNames` 一一对应**：`ShopCategory` 里故意没有 `All` 成员，
   `全部` 是 `TabNames` 的最后一项（`AllTabIndex`），由 `_isAllTab` 控制。
   之前版本把 `All = 0` 放进枚举，导致 `TabNames[i]` 与类别错位一格，材料页签直接消失——
   数据上物品还在，界面上却点不到。以后加页签时先检查这个对应关系。
7. 搜索用的英文名是通过临时切换 `GameManager.language` 再调用 `GetTextByItems()` 拿到的
   （游戏的名称表是私有的，按 language 选择）。只能在主线程、构建目录时做，用完立刻还原。
8. **背包着色只能反射，不能直接访问**：`MyBagControl.myBag_GOBJ` / `targetBag_GOBJ`
   在 `MyBagControl.cs:12,14,16` 是 `private GameObject`。所以走 `AccessTools.Field`，
   取不到就记一条 warning 然后**永久停用背包着色**（不会反复刷日志、不会抛异常）。
9. **不要用 `bag.Count` 遍历背包格子**：`CurrentDataHub.myBag` 是
   `Dictionary<int, CurrentItemData>`，键是格子索引。遍历要按子物体数量走
   `transform.childCount` 并对字典做 `TryGetValue`，否则遇到空洞会抛异常。
10. **背包底色必须避开拖拽状态**：`MyBagControl.isTouch` 为真时游戏正在用格子颜色表达
    "拖拽起点 / 无效放置目标"，补丁此时必须整体跳过，否则会破坏放置高亮。
11. **`TierTest` / `MetaCheck` 放在 `src\` 下、`RareShop\` 之外**是刻意的：
   SDK 风格工程会 glob 自己目录下的 `**\*.cs`，放进去会被重复编译出 `Main` 冲突。

## 运行时验证方法

- 日志：`NightRaider\BepInEx\LogOutput.log`
- 游戏自身日志：`%USERPROFILE%\AppData\LocalLow\TSUKUYOMIC\NightRaider\Player.log`
  （BepInEx 的 `LogConsoleToUnityLog=true` 时也会写到这里，BepInEx 崩了也能看到）
- 截图键 `F9` → `NightRaider\BepInEx\Screenshots\*.png`

## 游戏侧关键 API（已核对，附源码位置）

| 用途 | 调用 | 位置 |
|---|---|---|
| 玩家 GP | `DataHub.CheckMyGP()` / `ChangeMyGP(int)` | DataHub.cs:3601 / 3606 |
| 物品表 | `DataHub.itemDataDic` (id → `ItemData`) | DataHub.cs:14 |
| 物品名 | `TextManager.GetTextByItems(id)` | TextManager.cs:2530 |
| 物品图标 | `ResourcesHub.imageDic[id]` | ResourcesHub.cs:7 |
| 背包/仓库 | `CurrentDataHub.myBag`、`depotA_Bag`…（各 117 格，`Dictionary<int,CurrentItemData>`） | CurrentDataHub.cs:25 / 121 |
| 放物品 | 自实现：`CheckSpaceByBag` + `CreateNewItem`/`CreateCompWeapon` + `AutoOccupyBagGrid` | CurrentDataHub.cs:5678 / 7619 / 7065 / 5659 |
| 存盘 | `DataHub.SaveBag()` / `SaveDepot(pos)` / `SaveRecord()` | DataHub.cs:4084 / 4117 / 4079 |
| 载入存档 | `GameManager.InitializeData()`（先设 `archiveFileID`：1=D1202, 2=E1203, 3=F1204） | GameManager.cs:960 / JsonManager.cs:131 |
| 窗口判定 | `GameManager.CheckWindowOpen()`（Harmony Postfix 让它认我们的窗口） | GameManager.cs:1023 |

## 商品分类依据

`ItemData.itemTyep`：1=武器，2=可穿戴装备，3=武器配件，4=消耗品/杂物。
3000 段的 `itemPos` 是子类型：1=药品，2=投掷物，3=食物/饮料，4=工具/无人机。
4000 段为材料、弹药、钥匙、证件等。

`canUse` 字段在游戏里是**死字段**（只赋值、从不读取），不要拿它判断可用性。
