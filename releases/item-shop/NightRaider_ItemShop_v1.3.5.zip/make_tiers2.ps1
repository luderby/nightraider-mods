﻿# Generates the item rarity table from DROP MECHANICS instead of price.
#
# Reference difficulty: the game's default new-game config. MenuMessage.Start sets every
# hardLevelDic entry to 3 and hardLevelDic[12] to 1, so the default "搜刮资源难度"
# (hardCoreDic[8]) is 3 -> GetLootRateByHard() = 0. The lowest map is hardCode 0.
# With boxBonus 4 (boxLevel <= 0) that gives:
#     num2 = 1 + 4 + 0 = 5 ,  E = num2 + hardCode = 5
#
# Rules
#   * equipment 5000-5023 / 5030 / 5031 : workbench upgrade chain, stretched 1/2/4/5
#   * backpacks 4624-4628               : workbench upgrade chain, 1:1 to tiers 1..5
#   * weapons in Goods_Weapon_Map*      : unlock tier (earliest Map) + per-pool entry weight
#   * everything else with a drop pool  : per-category percentile of the spawn weight
#   * price                             : only an outlier correction (never the primary)
#   * neither droppable nor craftable   : tier 0 = pending, listed in a separate CSV

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$E_REF = 5

# --------------------------------------------------------------- tuning knobs
# A tier is decided from a score in [0,1] built out of two WITHIN-CATEGORY signals:
#   rarity = 1 - spawn percentile   (how rare the item is inside its own category)
#   value  = price percentile        (how valuable it is inside its own category)
# Everything is compared inside a category on purpose: prices are not comparable across
# categories (ammo medians at 51 GP, weapons at 26800), so a cross-category comparison
# would call every grenade legendary and every treasure common.
#
# The price weight is deliberately the larger one: the user's rule is "high-value items must
# not end up low", while "low-value AND common" must land low -- which a both-signals blend
# gives naturally, since a low value drags an otherwise-rare item back down.
$W_SPAWN = 0.45
$W_PRICE = 0.55

# score -> tier cutoffs
$T5 = 0.88
$T4 = 0.70
$T3 = 0.45
$T2 = 0.22

function ScoreToTier([double]$s) {
    if ($s -ge $T5) { return 5 }
    if ($s -ge $T4) { return 4 }
    if ($s -ge $T3) { return 3 }
    if ($s -ge $T2) { return 2 }
    return 1
}

# Absolute-price ceiling. Percentiles are relative, so inside a cheap category the priciest
# member is called "legendary" even though it may cost a few hundred GP. This caps how high
# an item can go on price-derived reasoning alone. It never applies to tiers that come from
# explicit game data (workbench craft tier, equipment/backpack chains) or from hand editing.
function PriceCeiling([int]$price) {
    if ($price -lt 500) { return 2 }
    if ($price -lt 2000) { return 3 }
    if ($price -lt 10000) { return 4 }
    return 5
}

# Explicit per-item overrides, applied LAST (after every rule and after the price ceiling)
# so they always win. Use these for items whose computed tier is wrong for a reason the
# drop data cannot express; they survive regeneration, unlike a hand edit to the output.
# Tier -> default colour: 1 grey C9C9C9, 2 green 5FBF5F, 3 blue 4D8CE6, 4 purple A85CD9,
# 5 orange F2A33C.
$TIER_OVERRIDES = @{
    4622 = 2   # 警用枪袋 (18800 GP): user asked for a lower tier; tier 2 renders green.
               # The computed tier was 4, which also inverted against 4623 专业枪支保险箱
               # (36800 GP, tier 3) -- the cheaper bag was rating higher than the dearer one.
}

# ---------------------------------------------------------------- pools
$dh = Get-Content (Join-Path $root 'game_src\DataHub.cs') -Encoding UTF8
$pools = @{}
for ($i = 0; $i -lt $dh.Count; $i++) {
    if ($dh[$i] -match 'public List<int>\s+([A-Za-z_0-9]+)\s*=\s*new List<int>\s*\{?\s*(.*)$') {
        $name = $Matches[1]; $j = $i; $buf = $Matches[2]
        while ($buf -notmatch '\}' -and $j -lt $dh.Count - 1) { $j++; $buf += ' ' + $dh[$j].Trim() }
        $pools[$name] = @([regex]::Matches($buf, '(?<![\d.])\d{3,7}(?![\d.])') | ForEach-Object { [int]$_.Value })
    }
}
Write-Host ("pools: {0}" -f $pools.Count)

# workbench recipe targets (GetCraftItemMet) and their craft tiers
$craft = @{}
for ($i = 12693; $i -lt 13590 -and $i -lt $dh.Count; $i++) {
    if ($dh[$i] -match '^\s*case (\d+):') { $craft[[int]$Matches[1]] = $true }
}
$craftTier = @{}
foreach ($c in 'craft01', 'craft02', 'craft03', 'craft04', 'craft05') {
    if (-not $pools.ContainsKey($c)) { continue }
    $lvl = [int]$c.Substring(6)
    foreach ($id in ($pools[$c] | Select-Object -Unique)) {
        if (-not $craftTier.ContainsKey($id) -or $craftTier[$id] -gt $lvl) { $craftTier[$id] = $lvl }
    }
}
Write-Host ("workbench targets: {0}, with craft tier: {1}" -f $craft.Count, $craftTier.Count)

# ---------------------------------------------------------------- catalog
$raw = Get-Content (Join-Path $root 'item_catalog.json') -Raw -Encoding UTF8
$b = $raw.IndexOf('"items": ['); $e = $raw.IndexOf('"categoryCounts"')
$items = @{}
foreach ($o in ([regex]::Split($raw.Substring($b, $e - $b), '(?=\{\s*\r?\n\s*"modelId":)') | Where-Object { $_ -match '"modelId":' })) {
    $id = [int]([regex]::Match($o, '"modelId":\s*(\d+)').Groups[1].Value)
    $items[$id] = [pscustomobject]@{
        Id = $id
        Cn = [regex]::Match($o, '"nameCn":\s*"([^"]*)"').Groups[1].Value
        En = [regex]::Match($o, '"nameEn":\s*"([^"]*)"').Groups[1].Value
        Cat = [regex]::Match($o, '"category":\s*"([A-Z_]+)"').Groups[1].Value
        Price = [int]([regex]::Match($o, '"price":\s*(\d+)').Groups[1].Value)
    }
}
Write-Host ("catalog items: {0}" -f $items.Count)

# ---------------------------------------------------------------- ladders + spawn weight
$bl = Get-Content (Join-Path $root 'game_src\BuildingControl.cs') -Encoding UTF8
$start = -1
for ($i = 0; $i -lt $bl.Count; $i++) { if ($bl[$i] -match '^\tpublic void GetBagContent\(\)') { $start = $i; break } }
$end = $bl.Count
for ($i = $start + 1; $i -lt $bl.Count; $i++) { if ($bl[$i] -match '^\t(public|private|protected)\s') { $end = $i; break } }

function Get-Indent([string]$s) { $n = 0; while ($n -lt $s.Length -and $s[$n] -eq "`t") { $n++ }; return $n }
function Get-Threshold([string]$x) {
    $x = $x.Trim()
    if ($x -eq 'ELSE') { return @('ELSE', 0.0) }
    if ($x -match '^(\d+)\s*-\s*num2\s*-\s*ManagerBase<TerrainManager>\.Instance\.hardCode$') { return @('E', [double]$Matches[1]) }
    if ($x -match '^(\d+)\s*-\s*num2$') { return @('N', [double]$Matches[1]) }
    if ($x -match '^(\d+)\s*-\s*ManagerBase<TerrainManager>\.Instance\.hardCode$') { return @('H', [double]$Matches[1]) }
    if ($x -match '^(\d+)$') { return @('C', [double]$Matches[1]) }
    return @('X', 0.0)
}

$weight = @{}
$ladders = 0
$case = 0; $i = $start
while ($i -lt $end) {
    $t = $bl[$i].Trim()
    if ($t -match '^case (\d+):') { $case = [int]$Matches[1]; $i++; continue }
    if ($t -match '^for \(') {
        $bodyIndent = (Get-Indent $bl[$i]) + 1
        $j = $i + 1
        while ($j -lt $end -and $bl[$j].Trim() -eq '') { $j++ }
        if ($j -lt $end -and $bl[$j].Trim() -eq '{') { $j++ }
        while ($j -lt $end -and ($bl[$j].Trim() -eq '' -or (Get-Indent $bl[$j]) -gt $bodyIndent)) { $j++ }
        if ($j -lt $end -and (Get-Indent $bl[$j]) -eq $bodyIndent) {
            if ($bl[$j].Trim() -match '^if \(ToolManager\.Lottery\((.+)\)\)$') {
                $thr = @($Matches[1]); $pn = @(''); $branch = 0; $depth = 0; $k = $j + 1
                while ($k -lt $end) {
                    $kt = $bl[$k].Trim()
                    if ($kt -eq '') { $k++; continue }
                    if ($kt -eq '{') { $depth++; $k++; continue }
                    if ($kt -eq '}') { $depth--; if ($depth -lt 0) { break }; $k++; continue }
                    if ($depth -eq 0) {
                        if ($kt -match '^else if \(ToolManager\.Lottery\((.+)\)\)$') { $thr += $Matches[1]; $pn += ''; $branch = $thr.Count - 1; $k++; continue }
                        if ($kt -eq 'else') { $thr += 'ELSE'; $pn += ''; $branch = $thr.Count - 1; $k++; continue }
                        break
                    }
                    if ($pn[$branch] -eq '' -and $kt -match 'GetSingleRandomCount\(ManagerBase<DataHub>\.Instance\.(\w+)\)') { $pn[$branch] = $Matches[1] }
                    $k++
                }
                $rem = 1.0
                for ($q = 0; $q -lt $thr.Count; $q++) {
                    $tb = Get-Threshold $thr[$q]
                    if ($tb[0] -eq 'ELSE') { $p = $rem; $rem = 0.0 }
                    else {
                        $th = $tb[1]
                        if ($tb[0] -eq 'E') { $th = $tb[1] - $E_REF }
                        if ($th -gt 100) { $th = 100 }; if ($th -lt 0) { $th = 0 }
                        $p = $rem * ($th / 100.0); $rem -= $p
                    }
                    if ($p -le 0) { continue }
                    $pool = $pn[$q]
                    if ($pool -eq '' -or -not $pools.ContainsKey($pool)) { continue }
                    $list = $pools[$pool]
                    if ($list.Count -eq 0) { continue }
                    $per = $p / $list.Count
                    foreach ($id in $list) {
                        if (-not $weight.ContainsKey($id)) { $weight[$id] = 0.0 }
                        $weight[$id] += $per
                    }
                }
                $ladders++
            }
        }
        $i = $j; continue
    }
    $i++
}
Write-Host ("ladders evaluated: {0}, items with a spawn weight: {1}" -f $ladders, $weight.Count)

# ---------------------------------------------------------------- helpers
function Get-PctRank($ids, $valueOf) {
    # returns id -> percentile of value, 0 = smallest value, 1 = largest
    $sorted = $ids | Sort-Object { $valueOf.Invoke($_) }
    $n = $sorted.Count
    $map = @{}
    for ($q = 0; $q -lt $n; $q++) {
        $map[$sorted[$q]] = if ($n -le 1) { 0.0 } else { $q / [double]($n - 1) }
    }
    return $map
}

# per-category price percentile and price tier
$pricePct = @{}
$priceTier = @{}
foreach ($g in ($items.Values | Group-Object Cat)) {
    $ids = @($g.Group | ForEach-Object { $_.Id })
    $sorted = $g.Group | Sort-Object Price
    $n = $sorted.Count
    for ($q = 0; $q -lt $n; $q++) {
        $p = if ($n -le 1) { 0.0 } else { $q / [double]($n - 1) }
        $pricePct[$sorted[$q].Id] = $p
        $t = [int][math]::Floor($p * 5) + 1     # 1..5, cheap -> 1
        if ($t -gt 5) { $t = 5 }
        $priceTier[$sorted[$q].Id] = $t
    }
}

# Global price tier, used only by the fallback branches (items with no probability data at
# all). The per-category price tier is wrong for those: inside AMMO the dearest item is a
# 1680 GP grenade, which per-category ranking would call legendary. Globally it is cheap.
$priceTierGlobal = @{}
$allById = $items.Values | Sort-Object Price
$gn = $allById.Count
for ($q = 0; $q -lt $gn; $q++) {
    $p = if ($gn -le 1) { 0.0 } else { $q / [double]($gn - 1) }
    $t = [int][math]::Floor($p * 5) + 1
    if ($t -gt 5) { $t = 5 }
    $priceTierGlobal[$allById[$q].Id] = $t
}

# per-category spawn percentile (0 = rarest because weight is small)
$spawnPct = @{}
$spawnTier = @{}
foreach ($g in ($items.Values | Group-Object Cat)) {
    $withW = @($g.Group | Where-Object { $weight.ContainsKey($_.Id) })
    if ($withW.Count -eq 0) { continue }
    $sorted = $withW | Sort-Object { $weight[$_.Id] }   # ascending weight = rarest first
    $n = $sorted.Count
    for ($q = 0; $q -lt $n; $q++) {
        $p = if ($n -le 1) { 0.0 } else { $q / [double]($n - 1) }
        $spawnPct[$sorted[$q].Id] = $p
        # rarest 8% -> 5, next 17% -> 4, next 25% -> 3, next 25% -> 2, rest -> 1
        $t = 1
        if ($p -le 0.08) { $t = 5 }
        elseif ($p -le 0.25) { $t = 4 }
        elseif ($p -le 0.50) { $t = 3 }
        elseif ($p -le 0.75) { $t = 2 }
        $spawnTier[$sorted[$q].Id] = $t
    }
}

# ---------------------------------------------------------------- weapon unlock tier
# Union of every Goods* pool. A container ladder only covers part of the game's item
# sources: the NPC shop inventories (GoodsBag_GunShop_*, GoodsBag_MedicShop_*) are pools
# too, but they are read by NPCControl rather than by a loot ladder, so items sold there
# carry no ladder weight. Those still "have a source", so they fall back to price.
$allPoolItems = @{}
foreach ($k in $pools.Keys) {
    if ($k -notlike 'Goods*') { continue }
    foreach ($id in $pools[$k]) { $allPoolItems[$id] = $true }
}
# Enemy corpses and the scavenger hand out literal ids (e.g. CreateNewItem(4604, 1)) rather
# than drawing from a named pool, so those items would otherwise look sourceless.
$literalDrop = @{}
foreach ($fn in 'CharaState.cs', 'BuildingControl.cs', 'CurrentDataHub.cs', 'NPCControl.cs', 'MonsterManager.cs', 'DropItem.cs') {
    $p = Join-Path $root ('game_src\' + $fn)
    if (-not (Test-Path $p)) { continue }
    $txt = Get-Content $p -Raw -Encoding UTF8
    foreach ($m in [regex]::Matches($txt, 'CreateNewItem\(\s*(\d{3,5})\s*,')) { $literalDrop[[int]$m.Groups[1].Value] = $true }
    foreach ($m in [regex]::Matches($txt, 'GetNewBagGoods\([^,]+,\s*(\d{3,5})\s*,')) { $literalDrop[[int]$m.Groups[1].Value] = $true }
    foreach ($m in [regex]::Matches($txt, 'ResetData\(ManagerBase<CurrentDataHub>\.Instance\.CreateNewItem\((\d{3,5})')) { $literalDrop[[int]$m.Groups[1].Value] = $true }
}
Write-Host ("items reachable from at least one Goods* pool: {0}" -f $allPoolItems.Count)
Write-Host ("items handed out by enemy/scavenger literals: {0}" -f $literalDrop.Count)

# Weapon availability is computed straight from the Map pools rather than from the loot
# ladders. A container never names a weapon pool: it calls GetWeaponListByHardcode(), which
# picks Goods_Weapon_Map1..Map6 from hardCode. Averaging over the six map levels (one
# hardCode value each, so 1/6 apiece) gives every weapon an average availability, and going
# through the list by entry makes the repeated entries count as the weights they are.
$weaponMapWeight = @{}
foreach ($mk in 1..6) {
    $mp = "Goods_Weapon_Map$mk"
    if (-not $pools.ContainsKey($mp)) { continue }
    $mlist = $pools[$mp]
    if ($mlist.Count -eq 0) { continue }
    $per = (1.0 / 6.0) / $mlist.Count
    foreach ($id in $mlist) {
        if (-not $weaponMapWeight.ContainsKey($id)) { $weaponMapWeight[$id] = 0.0 }
        $weaponMapWeight[$id] += $per
    }
}
Write-Host ("weapons given a Map-derived availability: {0}" -f $weaponMapWeight.Count)

$mapPools = 1..6 | ForEach-Object { "Goods_Weapon_Map$_" }
$unlock = @{}
foreach ($k in 1..6) {
    $p = "Goods_Weapon_Map$k"
    if (-not $pools.ContainsKey($p)) { continue }
    foreach ($id in ($pools[$p] | Select-Object -Unique)) {
        if (-not $unlock.ContainsKey($id) -or $unlock[$id] -gt $k) { $unlock[$id] = $k }
    }
}

# weapon availability percentile (within weapons only), the "probability" half of the rule
$weaponIds = @($weaponMapWeight.Keys)
$weaponSpawnPct = Get-PctRank $weaponIds { param($x) $weaponMapWeight[$x] }

# ---------------------------------------------------------------- assign tiers
$rows = New-Object System.Collections.ArrayList
foreach ($it in ($items.Values | Sort-Object Id)) {
    $id = $it.Id
    $tier = 0
    $reason = ''
    $src = ''
    $exemptFromCeiling = $false

    # --- equipment: workbench upgrade chain, stretched 1/2/4/5 -----------------
    if ($id -ge 5000 -and $id -le 5019) {
        $lvl = ($id - 5000) % 4              # 0 simple, 1 reinforced, 2 military, 3 special
        $tier = @(1, 2, 4, 5)[$lvl]
        $reason = 'workbench upgrade chain (same slot level ' + $lvl + '), stretched 1/2/4/5'
        $src = 'equipment'
    }
    elseif ($id -eq 5020 -or $id -eq 5022) { $tier = 4; $reason = 'workbench upgrade chain (lower of pair)'; $src = 'equipment' }
    elseif ($id -eq 5021 -or $id -eq 5023) { $tier = 5; $reason = 'workbench upgrade chain (upper of pair)'; $src = 'equipment' }
    elseif ($id -eq 5030 -or $id -eq 5031) { $tier = 5; $reason = 'workbench top-tier standalone piece'; $src = 'equipment' }
    # --- backpacks: 5-step workbench chain, 1:1 -------------------------------
    elseif ($id -ge 4624 -and $id -le 4628) {
        $tier = $id - 4624 + 1
        $reason = 'workbench backpack chain step ' + $tier + '/5'
        $src = 'backpack'
    }
    # --- weapons: unlock ladder as the base, refined by availability + value ---
    elseif ($it.Cat -eq 'WEAPON' -and $unlock.ContainsKey($id)) {
        $u = $unlock[$id]
        # Spread the six Map levels evenly over five tiers: Map1->1 Map2->1 Map3->2
        # Map4->3 Map5->4 Map6->5. Using ceil(u*5/6) instead would squash Map5 and Map6
        # together and put 58% of all weapons on tier 5.
        $base = 1 + [int][math]::Floor(($u - 1) * 4.0 / 5.0)
        if ($base -gt 5) { $base = 5 }
        if ($base -lt 1) { $base = 1 }

        $p = $weaponSpawnPct[$id]
        $blend = $W_SPAWN * (1.0 - $p) + $W_PRICE * $pricePct[$id]
        $adj = 0
        if ($blend -ge 0.75) { $adj = 1 } elseif ($blend -le 0.25) { $adj = -1 }
        $tier = $base + $adj
        if ($tier -lt 1) { $tier = 1 }; if ($tier -gt 5) { $tier = 5 }
        $reason = 'weapon: earliest Map' + $u + ' -> base ' + $base
        $reason += '; within-weapons blend(avail=' + [math]::Round($p, 2) + ', value=' + [math]::Round($pricePct[$id], 2) + ')=' + [math]::Round($blend, 2) + ' -> adj ' + $adj
        $src = 'weapon'
    }
    elseif ($it.Cat -eq 'WEAPON' -and $craftTier.ContainsKey($id)) {
        $tier = $craftTier[$id]
        $reason = 'weapon: no drop pool, workbench craft tier ' + $tier
        $src = 'weapon-craft'
        $exemptFromCeiling = $true
    }
    # --- other weapon sources: the NPC gun shop pools ------------------------
    elseif ($it.Cat -eq 'WEAPON' -and $allPoolItems.ContainsKey($id)) {
        $tier = $priceTier[$id]
        $reason = 'weapon: only in an NPC shop pool (no loot ladder) -> within-category price tier ' + $tier
        $src = 'weapon-shop'
    }
    # --- main path: within-category blend of drop rarity and value -----------
    elseif ($spawnTier.ContainsKey($id)) {
        $rarity = 1.0 - $spawnPct[$id]
        $value = $pricePct[$id]
        $score = $W_SPAWN * $rarity + $W_PRICE * $value
        $tier = ScoreToTier $score
        $reason = 'blend: 掉率稀有度=' + [math]::Round($rarity, 2) + ' 同类价值=' + [math]::Round($value, 2) + ' -> score=' + [math]::Round($score, 2)
        $src = 'spawn'
    }
    # --- pool-sourced but no loot-ladder weight: shop pools, one-off grants ---
    elseif ($allPoolItems.ContainsKey($id)) {
        $tier = $priceTier[$id]
        $reason = 'in a Goods* pool that no container ladder draws from (NPC shop etc.) -> within-category price tier ' + $tier
        $src = 'pool-price'
    }
    # --- handed out as a literal id by enemy / scavenger code -----------------
    elseif ($literalDrop.ContainsKey($id)) {
        $tier = $priceTier[$id]
        $reason = 'dropped as a literal id by enemy/scavenger code (no pool, no probability) -> within-category price tier ' + $tier
        $src = 'literal-drop'
    }
    # --- workbench-craftable but not reachable by any drop --------------------
    elseif ($craft.ContainsKey($id)) {
        if ($craftTier.ContainsKey($id)) {
            $tier = $craftTier[$id]
            $reason = 'workbench recipe, craft tier ' + $tier + '/5'
            $exemptFromCeiling = $true
        }
        else {
            $tier = $priceTier[$id]
            $reason = 'workbench recipe without a craft tier -> within-category price tier ' + $tier
        }
        $src = 'craft'
    }
    # --- gap ------------------------------------------------------------------
    else {
        $tier = 0
        $reason = 'PENDING: neither in a drop pool nor workbench-craftable'
        $src = 'pending'
        $exemptFromCeiling = $true
    }

    # Absolute-price ceiling: stops a cheap item from riding a cheap category's percentile
    # to a high tier. Explicit game data (craft tier, equipment/backpack chain) and hand
    # assignments are exempt, because those are real design facts, not percentile reasoning.
    if (-not $exemptFromCeiling -and $tier -gt 0) {
        $ceil = PriceCeiling $it.Price
        if ($tier -gt $ceil) {
            $tier = $ceil
            $reason += '; 绝对价格上限 -> ' + $ceil + '（' + $it.Price + ' GP）'
        }
    }

    # Explicit overrides win over everything above.
    if ($TIER_OVERRIDES.ContainsKey($id)) {
        $reason = 'override -> ' + $TIER_OVERRIDES[$id] + '（原判定 ' + $tier + '）; ' + $reason
        $tier = $TIER_OVERRIDES[$id]
        $src = 'override'
    }

    [void]$rows.Add([pscustomobject]@{
            modelId = $id
            tier = $tier
            nameCn = $it.Cn
            nameEn = $it.En
            category = $it.Cat
            price = $it.Price
            spawnWeight = if ($weight.ContainsKey($id)) { [math]::Round($weight[$id], 6) } else { '' }
            spawnPct = if ($spawnPct.ContainsKey($id)) { [math]::Round($spawnPct[$id], 3) } else { '' }
            priceTier = $priceTier[$id]
            source = $src
            reason = $reason
        })
}

$outCsv = Join-Path $root 'item_tiers.csv'
$rows | Export-Csv $outCsv -NoTypeInformation -Encoding UTF8
Write-Host ''
Write-Host ("wrote {0}  ({1} rows)" -f $outCsv, $rows.Count)
Write-Host 'tier distribution:'
$rows | Group-Object tier | Sort-Object Name | ForEach-Object { Write-Host ("  tier {0}: {1}" -f $_.Name, $_.Count) }
Write-Host 'by source:'
$rows | Group-Object source | Sort-Object Count -Descending | ForEach-Object { Write-Host ("  {0,-14} {1}" -f $_.Name, $_.Count) }

# pending list for manual assignment. "suggestedTier" is only a starting point derived from
# the global price percentile; "tier" is the column the mod actually reads, so fill that in.
$pendingCsv = Join-Path $root 'item_tiers_pending.csv'
$rows | Where-Object { $_.source -eq 'pending' } |
    Select-Object modelId, tier,
        @{ n = 'suggestedTier'; e = { $priceTierGlobal[[int]$_.modelId] } },
        nameCn, nameEn, category, price, reason |
    Export-Csv $pendingCsv -NoTypeInformation -Encoding UTF8
Write-Host ''
Write-Host ("wrote {0}  ({1} rows to assign by hand)" -f $pendingCsv, ($rows | Where-Object { $_.source -eq 'pending' }).Count)
