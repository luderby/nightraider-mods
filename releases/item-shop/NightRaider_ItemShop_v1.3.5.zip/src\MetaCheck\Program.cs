using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;

namespace MetaCheck
{
    /// <summary>
    /// Reads assembly metadata only (no dependency resolution, so UnityEngine does not have
    /// to be loadable) and confirms the exact members the mod's Harmony patches target.
    ///
    /// This guards the one integration point that fails silently: BagRarity reflects on the
    /// private fields MyBagControl.myBag_GOBJ / targetBag_GOBJ. If a game update renames or
    /// re-types them, the mod would quietly stop colouring the bag, so the names are checked
    /// against the Assembly-CSharp.dll that is actually installed.
    /// </summary>
    internal static class Program
    {
        private static int _failures;

        private static void Check(bool ok, string what)
        {
            Console.WriteLine((ok ? "  ok   " : "  FAIL ") + what);
            if (!ok)
            {
                _failures++;
            }
        }

        private static int Main(string[] args)
        {
            if (args.Length < 1)
            {
                Console.Error.WriteLine("usage: MetaCheck <Assembly-CSharp.dll>");
                return 2;
            }

            string path = args[0];
            Console.WriteLine("== " + path + " ==");
            Console.WriteLine("  size " + new FileInfo(path).Length + " bytes, written " + File.GetLastWriteTime(path));

            using (FileStream fs = File.OpenRead(path))
            using (PEReader pe = new PEReader(fs))
            {
                MetadataReader md = pe.GetMetadataReader();

                // The plugin's own assembly identity: if the game swapped backends this changes.
                if (md.IsAssembly)
                {
                    AssemblyDefinition ad = md.GetAssemblyDefinition();
                    Console.WriteLine("  assembly " + md.GetString(ad.Name) + " v" + ad.Version);
                }

                TypeDefinitionHandle? bagHandle = null;
                foreach (TypeDefinitionHandle th in md.TypeDefinitions)
                {
                    if (md.GetString(md.GetTypeDefinition(th).Name) == "MyBagControl")
                    {
                        bagHandle = th;
                        break;
                    }
                }

                Check(bagHandle.HasValue, "type MyBagControl exists");
                if (!bagHandle.HasValue)
                {
                    Console.WriteLine(_failures + " CHECK(S) FAILED");
                    return 1;
                }

                TypeDefinition bag = md.GetTypeDefinition(bagHandle.Value);

                // --- fields the bag patch reflects on -----------------------------
                var wanted = new Dictionary<string, string>
                {
                    { "myBag_GOBJ", "GameObject" },
                    { "targetBag_GOBJ", "GameObject" },
                };
                var found = new Dictionary<string, string>();
                foreach (FieldDefinitionHandle fh in bag.GetFields())
                {
                    FieldDefinition fd = md.GetFieldDefinition(fh);
                    string fname = md.GetString(fd.Name);
                    if (wanted.ContainsKey(fname))
                    {
                        string typeName = TypeNameOf(md, fd);
                        bool isPrivate = (fd.Attributes & FieldAttributes.FieldAccessMask) == FieldAttributes.Private;
                        found[fname] = typeName;
                        Console.WriteLine("  field " + fname + " : " + typeName + " (" + fd.Attributes + ")");
                        Check(typeName == "GameObject" || typeName == "UnityEngine.GameObject",
                            fname + " is typed GameObject (got " + typeName + ")");
                        Check(isPrivate, fname + " is private (hence the reflection)");
                    }
                }
                foreach (KeyValuePair<string, string> kv in wanted)
                {
                    Check(found.ContainsKey(kv.Key), "field " + kv.Key + " exists");
                }

                // --- methods the patches target -----------------------------------
                var methods = new Dictionary<string, int>();
                foreach (MethodDefinitionHandle mh in bag.GetMethods())
                {
                    string mn = md.GetString(md.GetMethodDefinition(mh).Name);
                    int n;
                    methods.TryGetValue(mn, out n);
                    methods[mn] = n + 1;
                }

                Check(methods.ContainsKey("RefreshTheGrid"), "method MyBagControl.RefreshTheGrid exists");
                Check(methods.ContainsKey("RefreshAll"), "method MyBagControl.RefreshAll exists");
                // The depot (仓库 A-L) and every other target window go through this method
                // and never through RefreshTheGrid, so it needs its own hook.
                Check(methods.ContainsKey("RefreshTheTargetGrid"),
                    "method MyBagControl.RefreshTheTargetGrid exists");
            }

            // --- EXMessageControl: the hover tooltip ------------------------------
            using (FileStream fs = File.OpenRead(path))
            using (PEReader pe = new PEReader(fs))
            {
                MetadataReader md = pe.GetMetadataReader();
                foreach (TypeDefinitionHandle th in md.TypeDefinitions)
                {
                    if (md.GetString(md.GetTypeDefinition(th).Name) != "EXMessageControl")
                    {
                        continue;
                    }
                    TypeDefinition t = md.GetTypeDefinition(th);
                    bool beOpened = false;
                    foreach (MethodDefinitionHandle mh in t.GetMethods())
                    {
                        if (md.GetString(md.GetMethodDefinition(mh).Name) == "BeOpened")
                        {
                            beOpened = true;
                        }
                    }
                    Check(beOpened, "method EXMessageControl.BeOpened exists (tooltip hook)");

                    bool titleField = false;
                    foreach (FieldDefinitionHandle fh in t.GetFields())
                    {
                        FieldDefinition fd = md.GetFieldDefinition(fh);
                        if (md.GetString(fd.Name) == "proTitle")
                        {
                            titleField = true;
                            string tn = TypeNameOf(md, fd);
                            bool priv = (fd.Attributes & FieldAttributes.FieldAccessMask) == FieldAttributes.Private;
                            Check(tn == "Text" || tn == "UnityEngine.UI.Text",
                                "proTitle is typed Text (got " + tn + ")");
                            Check(priv, "proTitle is private (hence the reflection)");
                        }
                    }
                    Check(titleField, "field EXMessageControl.proTitle exists");
                }
            }

            // --- the other patch target ------------------------------------------
            using (FileStream fs = File.OpenRead(path))
            using (PEReader pe = new PEReader(fs))
            {
                MetadataReader md = pe.GetMetadataReader();
                bool gameManager = false;
                bool checkWindowOpen = false;
                foreach (TypeDefinitionHandle th in md.TypeDefinitions)
                {
                    if (md.GetString(md.GetTypeDefinition(th).Name) != "GameManager")
                    {
                        continue;
                    }
                    gameManager = true;
                    foreach (MethodDefinitionHandle mh in md.GetTypeDefinition(th).GetMethods())
                    {
                        if (md.GetString(md.GetMethodDefinition(mh).Name) == "CheckWindowOpen")
                        {
                            checkWindowOpen = true;
                        }
                    }
                }
                Check(gameManager, "type GameManager exists");
                Check(checkWindowOpen, "method GameManager.CheckWindowOpen exists");
            }

            Console.WriteLine();
            Console.WriteLine(_failures == 0 ? "ALL CHECKS PASSED" : _failures + " CHECK(S) FAILED");
            return _failures == 0 ? 0 : 1;
        }

        /// <summary>Resolves a field's type name, following a TypeReference into its parent namespace.</summary>
        private static string TypeNameOf(MetadataReader md, FieldDefinition fd)
        {
            BlobHandle blob = fd.Signature;
            BlobReader br = md.GetBlobReader(blob);

            // FieldSig: 0x06 <field type>
            if (br.ReadByte() != 0x06)
            {
                return "?";
            }

            SignatureTypeCode code = br.ReadSignatureTypeCode();
            if (code == SignatureTypeCode.TypeHandle)
            {
                EntityHandle handle = br.ReadTypeHandle();
                if (handle.Kind == HandleKind.TypeReference)
                {
                    TypeReference tr = md.GetTypeReference((TypeReferenceHandle)handle);
                    string ns = md.GetString(tr.Namespace);
                    string n = md.GetString(tr.Name);
                    return string.IsNullOrEmpty(ns) ? n : ns + "." + n;
                }
                if (handle.Kind == HandleKind.TypeDefinition)
                {
                    return md.GetString(md.GetTypeDefinition((TypeDefinitionHandle)handle).Name);
                }
            }
            return code.ToString();
        }
    }
}
