﻿# Merges the hand-assigned tiers back into the main rarity table.
#
# Input  : item_tiers_pending.csv  (produced by make_tiers2.ps1, then edited by hand)
# Output : item_tiers.csv          (the file the mod reads)
#
# How a row's tier is read:
#   * if the "tier" column is > 0, that value wins
#   * otherwise "suggestedTier" is used
#   Both are accepted on purpose: the first round of editing went into suggestedTier by
#   mistake, and there is no reason for that to be unrecoverable.
#
# The 16 quest/story items 4717..4732 are then forced to tier 4 so they stand out in the bag
# (their price is 1, so any price-derived tier would be meaningless).

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$pendingPath = Join-Path $root 'item_tiers_pending.csv'
$mainPath = Join-Path $root 'item_tiers.csv'

# Hand assignments live in their own file so that re-running make_tiers2.ps1 -- which
# overwrites item_tiers_pending.csv with a fresh suggestion list -- can never destroy them.
# item_tiers_pending.csv stays the fallback for the first round of editing.
$handPath = Join-Path $root 'item_tiers_hand.csv'
if (Test-Path $handPath) {
    $pendingPath = $handPath
    Write-Host 'reading hand assignments from item_tiers_hand.csv'
}
else {
    Write-Host 'item_tiers_hand.csv not found, falling back to item_tiers_pending.csv'
}

if (-not (Test-Path $pendingPath)) { throw "missing $pendingPath" }
if (-not (Test-Path $mainPath)) { throw "missing $mainPath" }

# A CSV field can contain a comma (this generator writes reasons like
# "blend: 掉率稀有度=0.9, 同类价值=0.8"), so a naive -split ',' corrupts the row. This is
# the same minimal RFC4180 handling the C# parser uses.
function Split-CsvLine([string]$line) {
    $out = New-Object System.Collections.ArrayList
    $sb = New-Object System.Text.StringBuilder
    $inQ = $false
    for ($k = 0; $k -lt $line.Length; $k++) {
        $ch = $line[$k]
        if ($inQ) {
            if ($ch -eq '"') {
                if ($k + 1 -lt $line.Length -and $line[$k + 1] -eq '"') {
                    [void]$sb.Append('"'); $k++
                }
                else { $inQ = $false }
            }
            else { [void]$sb.Append($ch) }
        }
        elseif ($ch -eq '"') { $inQ = $true }
        elseif ($ch -eq ',') { [void]$out.Add($sb.ToString()); [void]$sb.Clear() }
        else { [void]$sb.Append($ch) }
    }
    [void]$out.Add($sb.ToString())
    return , $out.ToArray()
}

# --- read the pending file. WPS/Excel save CSV as GBK without a BOM while this script writes
# UTF-8, so the encoding must be detected rather than guessed from the content.
# A BOM settles it; otherwise decode with a STRICT UTF-8 decoder, because valid GBK text
# almost always contains byte sequences that are illegal UTF-8, and a throw means GBK.
$bytes = [System.IO.File]::ReadAllBytes($pendingPath)
$encName = ''
$text = $null
if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
    $text = [System.Text.Encoding]::UTF8.GetString($bytes)
    $encName = 'UTF-8 (BOM)'
}
if ($null -eq $text) {
    try {
        $strict = New-Object System.Text.UTF8Encoding($false, $true)
        $text = $strict.GetString($bytes)
        $encName = 'UTF-8 (no BOM)'
    }
    catch {
        $text = [System.Text.Encoding]::GetEncoding(936).GetString($bytes)
        $encName = 'GBK (936)'
    }
}
Write-Host ("pending file decoded as {0}" -f $encName)

# Encoding.UTF8.GetString keeps the BOM as a leading U+FEFF, which would make the first
# header field "\uFEFFmodelId" and break the column lookup. StreamReader strips the BOM, a
# raw GetString does not, so strip it explicitly.
$text = $text.TrimStart([char]0xFEFF)

$lines = $text -split "`r?`n" | Where-Object { $_.Trim().Length -gt 0 }
if ($lines.Count -lt 2) { throw 'pending file has no data rows' }

$header = Split-CsvLine $lines[0]
$iId = [array]::IndexOf($header, 'modelId')
$iSug = [array]::IndexOf($header, 'suggestedTier')
$iTier = [array]::IndexOf($header, 'tier')
$iName = [array]::IndexOf($header, 'nameCn')
if ($iId -lt 0 -or ($iSug -lt 0 -and $iTier -lt 0)) {
    throw 'pending file is missing modelId and both tier / suggestedTier columns'
}

$assigned = @{}
$fromTier = 0
$fromSuggested = 0
foreach ($l in ($lines | Select-Object -Skip 1)) {
    $f = Split-CsvLine $l
    if ($f.Count -le $iId) { continue }
    $id = 0
    if (-not [int]::TryParse($f[$iId], [ref]$id)) { continue }

    $sug = 0
    if ($iSug -ge 0 -and $f.Count -gt $iSug) { [void][int]::TryParse($f[$iSug], [ref]$sug) }
    $t = 0
    if ($iTier -ge 0 -and $f.Count -gt $iTier) { [void][int]::TryParse($f[$iTier], [ref]$t) }

    $val = 0
    if ($t -ge 1 -and $t -le 5) { $val = $t; $fromTier++ }
    elseif ($sug -ge 1 -and $sug -le 5) { $val = $sug; $fromSuggested++ }

    if ($val -lt 1 -or $val -gt 5) {
        throw ("id {0} has no usable tier (tier='{1}' suggestedTier='{2}')" -f $id, $t, $sug)
    }
    $assigned[$id] = $val
}
Write-Host ("pending rows read: {0}  (from tier: {1}, from suggestedTier: {2})" -f $assigned.Count, $fromTier, $fromSuggested)

# --- quest / story items get a uniform tier so they are easy to spot --------------
# Applied to the WHOLE 4717..4732 range, not just the pending rows: 4722 士官IC卡 and
# 4725 丹尼尔的情报 are the same kind of quest item but already had a tier from another
# source (literal-drop), so they never appeared in the pending list. Their neighbours in
# the same id block are all tier 4, so leaving those two at tier 1 would look like a bug.
foreach ($id in @($assigned.Keys)) {
    if ($id -ge 4717 -and $id -le 4732) { $assigned[$id] = 4 }
}

# --- merge into the main table ---------------------------------------------------
$main = Import-Csv $mainPath -Encoding UTF8
$filled = 0
$stillZero = @()
foreach ($r in $main) {
    $id = [int]$r.modelId
    if ([int]$r.tier -gt 0) { continue }
    if (-not $assigned.ContainsKey($id)) { $stillZero += $id; continue }
    $r.tier = $assigned[$id]
    $r.source = 'hand'
    $r.reason = 'hand-assigned'
    $filled++
}

# force the quest range across the whole table (catches rows that were already tiered)
$questForced = 0
foreach ($r in $main) {
    $id = [int]$r.modelId
    if ($id -ge 4717 -and $id -le 4732) {
        if ([int]$r.tier -ne 4) { $questForced++ }
        $r.tier = 4
        $r.source = 'hand'
        $r.reason = 'quest/story item, forced to tier 4 so it stands out in the bag'
    }
}
Write-Host ("rows filled from the pending file: {0}; quest rows corrected: {1}" -f $filled, $questForced)

if ($stillZero.Count -gt 0) {
    Write-Host ("WARNING: {0} rows still have tier 0 and no assignment: {1}" -f $stillZero.Count, ($stillZero -join ', '))
}

$mainIds = @{}
foreach ($r in $main) { $mainIds[[int]$r.modelId] = $true }
$unused = @($assigned.Keys | Where-Object { -not $mainIds.ContainsKey($_) })
if ($unused.Count -gt 0) { Write-Host ("WARNING: assignment for ids not in the table: {0}" -f ($unused -join ', ')) }

$main | Export-Csv $mainPath -NoTypeInformation -Encoding UTF8
Write-Host ("wrote {0}" -f $mainPath)

# --- verify ---------------------------------------------------------------------
$check = Import-Csv $mainPath -Encoding UTF8
$zero = @($check | Where-Object { [int]$_.tier -le 0 })
$bad = @($check | Where-Object { [int]$_.tier -lt 1 -or [int]$_.tier -gt 5 })
Write-Host ''
Write-Host ("rows: {0}   tier<=0: {1}   out of range: {2}" -f $check.Count, $zero.Count, $bad.Count)
Write-Host 'tier distribution:'
$check | Group-Object tier | Sort-Object { [int]$_.Name } | ForEach-Object { Write-Host ("  tier {0}: {1}" -f $_.Name, $_.Count) }
Write-Host 'source distribution:'
$check | Group-Object source | Sort-Object Count -Descending | ForEach-Object { Write-Host ("  {0,-14} {1}" -f $_.Name, $_.Count) }
Write-Host ''
Write-Host 'quest items:'
$check | Where-Object { [int]$_.modelId -ge 4717 -and [int]$_.modelId -le 4732 } |
    Sort-Object { [int]$_.modelId } |
    ForEach-Object { Write-Host ("  {0}  tier={1}  {2}" -f $_.modelId, $_.tier, $_.nameCn) }
