# 稀有度表说明（ITEM_TIERS.md）

适用版本：NightRaider_ItemShop **v1.3.1**

## 1. 为什么需要这张表

**游戏里没有"稀有度"字段。** 这是核对反编译代码后的结论：

- `ItemData`（`DataHub.itemDataDic` 的值，94 行）没有 rarity / quality / grade 成员；
- `CurrentItemData`（背包物品实例，800 行）也没有；
- `EquipmentData.itemLevel` **存在但是死字段** —— `EquipmentData` 这个类在整个反编译源码里
  只被声明、从未被实例化引用，所以 `itemLevel` 拿不到；
- 全工程搜 `rarity|rareLevel|quality|Grade` 只命中 `Upgrade` 这类假匹配。

所以稀有度**无法"读取"**，只能由一张外部表定义。本 Mod 的做法是：
表由你拥有、你能改，Mod 只负责 `modelID → 档位 → 颜色` 的映射。

## 2. 表的位置

```
NightRaider\BepInEx\config\NightRaider_item_tiers.csv
```

- 首次运行若该文件不存在，插件会从 `BepInEx\plugins\NightRaider_item_tiers.csv`（随包模板）
  自动复制一份过来，所以文件被删也能恢复。
- 表不存在时**不报错**：Mod 保留游戏原色，只在日志里记一条 warning。

## 3. 格式

必需两列，按**表头名**定位，列顺序随意、多余列被忽略：

| 列名 | 说明 |
|---|---|
| `modelId` | 物品 ID（也接受 `id`） |
| `tier` | 档位 **1–5**（也接受 `rarity`） |

**`tier = 0` 表示"待定"**：这一行会被跳过，`TierOf` 返回 0，Mod **保留游戏原色**，
而不是按 1 档涂成"普通"。这是 v1.3.1 的行为（v1.3.0 会把 0 夹到 1 档，是 bug）。

随包的表还有 `nameCn` / `nameEn` / `category` / `price` / `spawnWeight` / `spawnPct` /
`priceTier` / `source` / `reason` 九列，**全部是给你看的证据**，Mod 不读。

解析器是标准 CSV：支持引号包裹字段、字段内逗号、`""` 转义引号。

## 4. 改完怎么生效

- **热重载**：每次按 `F8` 打开商店会重新读表（`Rarity/ReloadTableOnOpen`，默认开），
  改完 CSV 不用重启游戏。
- 表里没有的物品（`TierOf` 返回 0）不会被涂色，游戏原色保留。

## 5. 档位、名称与颜色

| 档位 | 默认名称 | 默认颜色 | 配置项 |
|---|---|---|---|
| 1 | 普通 | `C9C9C9` 灰白 | `Rarity/Tier1Name`、`Rarity/Tier1Color` |
| 2 | 优良 | `5FBF5F` 绿 | `Rarity/Tier2Name`、`Rarity/Tier2Color` |
| 3 | 稀有 | `4D8CE6` 蓝 | `Rarity/Tier3Name`、`Rarity/Tier3Color` |
| 4 | 史诗 | `A85CD9` 紫 | `Rarity/Tier4Name`、`Rarity/Tier4Color` |
| 5 | 传说 | `F2A33C` 橙 | `Rarity/Tier5Name`、`Rarity/Tier5Color` |

颜色写十六进制 `RRGGBB`（可带 `#`），格式错会静默回退到默认色。

| 配置项 | 默认 | 说明 |
|---|---|---|
| `Rarity/ShopRowBrightness` | `0.30` | 商店列表行着色强度（0=不着色，1=全亮） |
| `Rarity/BagCellBrightness` | `0.60` | 背包格子着色强度 |

## 6. 显示在哪里

| 位置 | 配置开关 | 行为 |
|---|---|---|
| 商店列表行 | `Rarity/ColorShopRows` | 行底色 = 档位色 × 强度；选中行与选中蓝混合 |
| 商店详情面板 | 同上 | 多一行"稀有度：史诗（4 档）" |
| 游戏自带背包/箱子格子 | `Rarity/ColorBagCells` | 见下 |

### 背包格子的优先级（重要）

游戏自己的 `MyBagControl.RefreshTheGrid` 已经在给格子上色，但那是**状态和粗分类**：
白=普通 / 灰=拖拽起点 / 暗红=无效放置目标 / **金=已标记（markList）** /
蓝=modelID 3000–3999 / 紫=modelID 2000–2999 / **红=已锁定（lockList）**。

Mod 的补丁跑在它们**之后**，并遵守三条规则：

1. **正在拖拽时完全不动**（`MyBagControl.isTouch` 为真），否则会破坏放置高亮；
2. **已锁定（红）和已标记（金）的格子保留游戏原色** —— 那是玩家自己设的状态；
3. 表里没有的物品保留游戏原色。

其余格子（**包括游戏的蓝/紫分类色**）都会变成稀有度色。装备栏槽位（头盔/护甲/武器格）
不在范围内：那里子物体层级嵌套、且游戏用红色表示"不可装配"。

## 7. 随包这张表是怎么推出来的

### 7.1 参考难度：E = 5

所有容器掉落的概率阈值都是 `基数 − num2 − hardCode` 的形式，所以只取决于
**E = num2 + hardCode**。

按**游戏开局默认配置 + 最低难度**取值（`MenuMessage.Start` 把 `hardLevelDic` 全设为 3，
即"普通"，所以默认"搜刮资源难度"= 3 → `GetLootRateByHard()` = 0；最低地图 `hardCode` = 0）：

```
num2 = 1 (基础) + 4 (boxLevel<=0 → boxBonus) + 0 (搜刮资源难度=普通) = 5
E    = num2 + hardCode = 5 + 0 = 5
```

`num2` 还会被这些加成推高（每 +1 就把阈值压低一档）：技能 80104 最高 +4、
料理 213 +2、周年活动（1/27–2/9）+2；装备 `boxLevel` 若是 1–3 则 `boxBonus` 降为 1–3。

### 7.2 五条规则

`source` 列记录了每行走的是哪条：

| source | 件数 | 规则 |
|---|---|---|
| `spawn` | 1072 | `权重 = Σ_容器 Σ_支路 P(支路\|E=5) × 条目数 / 池大小`，再按**同类内**分位切档 |
| `weapon` | 74 | 最早出现的 `Goods_Weapon_Map1..6` → 基础档，再按 Map 可用性分位 ±1，最后价格修正 |
| `hand` | 56 | 你手工指定（54 件待定 + 2 件任务物品） |
| `pool-price` | 48 | 在 Goods\* 池里但没有阶梯权重（NPC 商店池）→ **全局**价格分位 |
| `craft` | 36 | 工作台可制作但无掉落 → 合成等级，无等级则全局价格分位 |
| `literal-drop` | 32 | 敌人/拾荒者用字面 ID 发放 → 全局价格分位 |
| `equipment` | 26 | 工作台升级链，**拉伸 1/2/4/5** |
| `weapon-shop` | 24 | 仅在 NPC 枪店池 → 全局价格分位 |
| `backpack` | 5 | 工作台背包升级链，**1:1 映射 1..5** |
| `weapon-craft` | 2 | 仅可制作的武器 → 合成等级 |

### 7.3 关键实现细节（踩过的坑）

**① 池内"无权重"是错的 —— 靠重复列举加权。**
`GetSingleRandomCount` 确实是 `list[Random.Range(0, count)]`（单条目等概率），
但游戏**把同一件物品在列表里重复写多次**来做权重：`Goods_Weapon_Map6` 有 103 个条目、
只有 **49 个去重**，其中 `1028 / 1018 / 1012 / 1029` 各重复 **6 次**。
所以算概率必须按**条目数**遍历，不能按去重数。

**② 武器掉落不经过命名池。**
容器的武器槽调用的是 `GetWeaponListByHardcode()`，它按 `hardCode` 在
`Goods_Weapon_Map1..6` 之间选（hc0: 98/1.98/0.02% → hc5: 40/48/12%），**阈值里不含 hardCode**。
因此武器权重是按 6 个 Map 均分（各 1/6）独立算的，不依赖容器阶梯解析。

**③ 容器常串联多个独立抽奖。**
一个箱子的代码里往往依次跑"银行池抽奖 → 弹药池抽奖 → 投掷物池抽奖…"，
所以"每个 `for` 循环只取第一个阶梯"的解析方式会漏。
这也是为什么武器权重改用独立模型（见 ②）。

**④ 兜底分支必须用全局价格分位，不能用同类内分位。**
同类内分位会让便宜类别里最贵的东西变成"传说"：`4701 破片榴弹` 只有 1680 GP，
却是最贵的弹药，一度被判 5 档。改用全局分位后 → 2 档。

**⑤ 装备来源只有工作台。**
`5000-5023` / `5030` / `5031` 这 26 件**不在任何掉落池、也不在任何商店列表**，
只在 `GetCraftItemMet`（工作台配方）里出现。等级就是同位置内的升级链：
`5000-5003` 简易/强化/军用/特种（头盔），`5004-5007` 护甲，`5008-5011` 护腿，
`5012-5015` 靴，`5016-5019` 手套 —— 即 `(id − 5000) % 4`。
按要求**拉伸到 1/2/4/5 档**（跳开 3 档）。
例外：`5024-5029`（防护服系列）不可制作但有敌人掉落，走概率规则。

**⑥ 背包升级链正好 5 档。**
`4624 简易背包 → 4625 旅行 → 4626 军用 → 4627 大容量 → 4628 扩展增强`，
全部工作台可制作，且 4625-4628 **无任何掉落**，所以 1:1 映射档位 1–5。

**⑦ 价格只做离群修正。**
主档位定完后，若与**同类内**价格档位相差 ≥2，就往价格方向拉 1 档。
共触发 276 次（约 20%）。`4701`、`4045 简易车钥匙`（690 GP）这类都是靠它拉回来的。

### 7.4 手工指定的 56 件

54 件来自 `item_tiers_pending.csv`（既不掉落也不可制作），用 `suggestedTier` 列作为最终档位，
其中手工改了 6 处：`1098→4`、`3162→3`、`4297→3`、`4339→3`、`4621→3`、`4732→4`。

另外 **16 件任务/剧情物品 `4717-4732` 统一给 4 档**（史诗/紫），让它们在背包里显眼好找。
注意这里比原本说的"14 件"多 2 件：`4722 士官IC卡` 和 `4725 丹尼尔的情报` 因为另有来源
（`literal-drop`）没有进待定清单，但同区段、同类物品，若留 1 档会看起来像 bug，所以一并覆盖。

### 7.5 最终档位分布

| 档位 | 数量 |
|---|---|
| 1 普通 | 260 |
| 2 优良 | 356 |
| 3 稀有 | 324 |
| 4 史诗 | 299 |
| 5 传说 | 134 |
| **合计** | **1373** |

## 8. 重新生成

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

# 1) 按掉落机制重新生成整张表（会覆盖 item_tiers.csv，并写出新的待定清单）
& .\make_tiers2.ps1

# 2) 人工填完 item_tiers_pending.csv 的 suggestedTier 列后，合并回主表
& .\merge_pending.ps1
```

`merge_pending.ps1` 会自动识别 GBK / UTF-8（WPS、Excel 存 CSV 常是 GBK 无 BOM），
并把 `4717-4732` 强制为 4 档。

辅助脚本：`spawn_chance.ps1`（算掉落权重分布与相关性）、`loot_chains.ps1`（提取容器池阶梯）。

## 9. 验证

三项离线验证，都不需要启动游戏：

| 验证 | 做法 | 结果 |
|---|---|---|
| CSV 解析器 | `src/TierTest` 把**真实的** `ItemTiers.cs` 编进测试工程跑真实 CSV；断言 1373 行全映射、无坏行、档位都在 1–5、未知 ID 返回 0、**未映射集合恰好等于 CSV 里 tier=0 的集合**、重载幂等 | ALL CHECKS PASSED |
| 补丁目标 | `src/MetaCheck` 只读 `Assembly-CSharp.dll` 元数据，确认 `MyBagControl.myBag_GOBJ` / `targetBag_GOBJ` 是 `private UnityEngine.GameObject`、`RefreshTheGrid` 与 `GameManager.CheckWindowOpen` 存在 | ALL CHECKS PASSED |
| 部署一致性 | 比对已部署 DLL / CSV 与构建产物的 SHA256 | MATCH |

补丁目标校验的意义：`BagRarity` 反射的是**私有字段**，游戏更新若改了字段名，
Mod 会安静地停止给背包上色；这个检查能在启动游戏前发现。

## 10. 尚未在游戏内验证

底色在真机上好不好看、会不会遮挡图标，**没有实机跑过**（启动验证时 Steam 未运行，
直接运行 `NightRaider.exe` 无法启动游戏）。请进游戏确认：

1. 商店行底色深浅 → 调 `Rarity/ShopRowBrightness`；
2. 背包格子是否盖住图标 → 调 `Rarity/BagCellBrightness`，或设 0 关掉。

日志里应有：

```
稀有度表已载入：...\BepInEx\config\NightRaider_item_tiers.csv（1373 行，映射 1373 个物品）
```
