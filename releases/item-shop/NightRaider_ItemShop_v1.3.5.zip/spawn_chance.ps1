# Per-item "spawn chance" at a fixed reference difficulty, to judge whether a pure
# probability-based rarity is viable.
#
# Definition used here:
#   chance(item) = sum over all container ladders and all their top-level branches of
#                  P(branch | E) * (times item appears in that branch's pool) / (pool size)
#
# i.e. "expected number of times this item is produced per one item-slot of every
# container type". Only the TOP-LEVEL branch is resolved; a branch that contains its own
# nested ladder is credited to the first pool name found inside it. That approximation is
# stated in the output.

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$lines = Get-Content (Join-Path $root 'game_src\BuildingControl.cs') -Encoding UTF8
$dataHub = Get-Content (Join-Path $root 'game_src\DataHub.cs') -Encoding UTF8

# --- pool contents from DataHub ----------------------------------------------
$pools = @{}
for ($i = 0; $i -lt $dataHub.Count; $i++) {
    if ($dataHub[$i] -match 'public List<int>\s+([A-Za-z_0-9]+)\s*=\s*new List<int>\s*\{?\s*(.*)$') {
        $name = $Matches[1]; $j = $i; $buf = $Matches[2]
        while ($buf -notmatch '\}' -and $j -lt $dataHub.Count - 1) { $j++; $buf += ' ' + $dataHub[$j].Trim() }
        $pools[$name] = @([regex]::Matches($buf, '(?<![\d.])\d{3,7}(?![\d.])') | ForEach-Object { [int]$_.Value })
    }
}
Write-Host ("pools parsed: {0}" -f $pools.Count)

# --- item prices/names -------------------------------------------------------
$raw = Get-Content (Join-Path $root 'item_catalog.json') -Raw -Encoding UTF8
$b = $raw.IndexOf('"items": ['); $e = $raw.IndexOf('"categoryCounts"')
$info = @{}
foreach ($o in ([regex]::Split($raw.Substring($b, $e - $b), '(?=\{\s*\r?\n\s*"modelId":)') | Where-Object { $_ -match '"modelId":' })) {
    $id = [int]([regex]::Match($o, '"modelId":\s*(\d+)').Groups[1].Value)
    $info[$id] = [pscustomobject]@{
        Cn = [regex]::Match($o, '"nameCn":\s*"([^"]*)"').Groups[1].Value
        Price = [int]([regex]::Match($o, '"price":\s*(\d+)').Groups[1].Value)
        Cat = [regex]::Match($o, '"category":\s*"([A-Z_]+)"').Groups[1].Value
    }
}

# --- reuse the ladder parser -------------------------------------------------
$start = -1
for ($i = 0; $i -lt $lines.Count; $i++) { if ($lines[$i] -match '^\tpublic void GetBagContent\(\)') { $start = $i; break } }
$end = $lines.Count
for ($i = $start + 1; $i -lt $lines.Count; $i++) { if ($lines[$i] -match '^\t(public|private|protected)\s') { $end = $i; break } }

function Get-Indent([string]$s) { $n = 0; while ($n -lt $s.Length -and $s[$n] -eq "`t") { $n++ }; return $n }
function Get-Kind([string]$x) {
    $x = $x.Trim()
    if ($x -eq 'ELSE') { return @('ELSE', 0.0) }
    if ($x -match '^(\d+)\s*-\s*num2\s*-\s*ManagerBase<TerrainManager>\.Instance\.hardCode$') { return @('E', [double]$Matches[1]) }
    if ($x -match '^(\d+)\s*-\s*num2$') { return @('N', [double]$Matches[1]) }
    if ($x -match '^(\d+)\s*-\s*ManagerBase<TerrainManager>\.Instance\.hardCode$') { return @('H', [double]$Matches[1]) }
    if ($x -match '^(\d+)$') { return @('C', [double]$Matches[1]) }
    return @('X', 0.0)
}

$E_REF = 8   # = difficulty 3 + loot-resource difficulty 3
$chance = @{}
$ladderCount = 0

$case = 0; $i = $start
while ($i -lt $end) {
    $t = $lines[$i].Trim()
    if ($t -match '^case (\d+):') { $case = [int]$Matches[1]; $i++; continue }
    if ($t -match '^for \(') {
        $bodyIndent = (Get-Indent $lines[$i]) + 1
        $j = $i + 1
        while ($j -lt $end -and $lines[$j].Trim() -eq '') { $j++ }
        if ($j -lt $end -and $lines[$j].Trim() -eq '{') { $j++ }
        while ($j -lt $end -and ($lines[$j].Trim() -eq '' -or (Get-Indent $lines[$j]) -gt $bodyIndent)) { $j++ }
        if ($j -lt $end -and (Get-Indent $lines[$j]) -eq $bodyIndent) {
            if ($lines[$j].Trim() -match '^if \(ToolManager\.Lottery\((.+)\)\)$') {
                $thr = @($Matches[1]); $pname = @('')
                $branch = 0; $depth = 0; $k = $j + 1
                while ($k -lt $end) {
                    $kt = $lines[$k].Trim()
                    if ($kt -eq '') { $k++; continue }
                    if ($kt -eq '{') { $depth++; $k++; continue }
                    if ($kt -eq '}') { $depth--; if ($depth -lt 0) { break }; $k++; continue }
                    if ($depth -eq 0) {
                        if ($kt -match '^else if \(ToolManager\.Lottery\((.+)\)\)$') { $thr += $Matches[1]; $pname += ''; $branch = $thr.Count - 1; $k++; continue }
                        if ($kt -eq 'ELSE_PLACEHOLDER') { }
                        if ($kt -eq 'else') { $thr += 'ELSE'; $pname += ''; $branch = $thr.Count - 1; $k++; continue }
                        break
                    }
                    if ($pname[$branch] -eq '' -and $kt -match 'GetSingleRandomCount\(ManagerBase<DataHub>\.Instance\.(\w+)\)') { $pname[$branch] = $Matches[1] }
                    $k++
                }
                # probabilities
                $rem = 1.0
                for ($q = 0; $q -lt $thr.Count; $q++) {
                    $kb = Get-Kind $thr[$q]
                    $p = 0.0
                    if ($kb[0] -eq 'ELSE') { $p = $rem; $rem = 0.0 }
                    else {
                        $th = $kb[1]
                        if ($kb[0] -eq 'E') { $th = $kb[1] - $E_REF }
                        if ($th -gt 100) { $th = 100 }; if ($th -lt 0) { $th = 0 }
                        $p = $rem * ($th / 100.0); $rem -= $p
                    }
                    $pn = $pname[$q]
                    if ($p -gt 0 -and $pn -ne '' -and $pools.ContainsKey($pn)) {
                        $list = $pools[$pn]
                        if ($list.Count -gt 0) {
                            $per = $p / $list.Count
                            foreach ($id in $list) {
                                if (-not $chance.ContainsKey($id)) { $chance[$id] = 0.0 }
                                $chance[$id] += $per
                            }
                        }
                    }
                }
                $ladderCount++
            }
        }
        $i = $j; continue
    }
    $i++
}

Write-Host ("ladders evaluated: {0}, distinct items given a chance: {1}" -f $ladderCount, $chance.Count)
Write-Host ''
Write-Host ('=== distribution of per-slot chance at E={0} (difficulty 3 + loot setting 3) ===' -f $E_REF)
$sorted = $chance.GetEnumerator() | Sort-Object Value
$n = $sorted.Count
for ($q = 1; $q -le 20; $q++) {
    $idx = [int][math]::Floor($n * $q / 20.0); if ($idx -ge $n) { $idx = $n - 1 }
    $v = $sorted[$idx]
    Write-Host ('  p{0,2}  {1,9:F4}%   id={2,-6} {3,8} GP  {4}' -f ($q * 5), ($v.Value * 100), $v.Name, $info[[int]$v.Name].Price, $info[[int]$v.Name].Cn)
}
Write-Host ''
Write-Host '=== the extremes ==='
Write-Host '  rarest 10:'
$sorted | Select-Object -First 10 | ForEach-Object {
    Write-Host ('    {0,9:F4}%  id={1,-6} {2,8} GP  {3}  [{4}]' -f ($_.Value * 100), $_.Name, $info[[int]$_.Name].Price, $info[[int]$_.Name].Cn, $info[[int]$_.Name].Cat)
}
Write-Host '  most common 10:'
$sorted | Select-Object -Last 10 | ForEach-Object {
    Write-Host ('    {0,9:F4}%  id={1,-6} {2,8} GP  {3}  [{4}]' -f ($_.Value * 100), $_.Name, $info[[int]$_.Name].Price, $info[[int]$_.Name].Cn, $info[[int]$_.Name].Cat)
}
Write-Host ''
Write-Host '=== does "rare" correlate with "expensive"? ==='
# Spearman rank correlation between spawn chance rank and price rank, per category.
foreach ($g in ($sorted | Group-Object { $info[[int]$_.Name].Cat })) {
    $items = $g.Group | Where-Object { $info[[int]$_.Name] -ne $null }
    if ($items.Count -lt 8) { continue }
    $byChance = $items | Sort-Object Value
    $rankC = @{}; $r = 1
    foreach ($x in $byChance) { $rankC[[int]$x.Name] = $r; $r++ }
    $byPrice = $items | Sort-Object { $info[[int]$_.Name].Price }
    $rankP = @{}; $r = 1
    foreach ($x in $byPrice) { $rankP[[int]$x.Name] = $r; $r++ }
    $nn = $items.Count
    $sumD2 = 0.0
    foreach ($x in $items) {
        $id = [int]$x.Name
        $d = $rankC[$id] - $rankP[$id]
        $sumD2 += $d * $d
    }
    $rho = 1 - (6 * $sumD2) / ($nn * ($nn * $nn - 1))
    Write-Host ('  {0,-20} n={1,-4} Spearman rho(chance vs price) = {2,6:F3}' -f $g.Name, $nn, $rho)
}
