using System;
using System.Collections.Generic;

// Minimal stubs for the only three external dependencies of the real ItemTiers.cs.
// Namespaces and member names must match what ItemTiers.cs expects.

namespace BepInEx
{
    internal static class Paths
    {
        internal static string ConfigPath = ".";
    }
}

namespace NightRaider.RareShop
{
    internal sealed class StubLog
    {
        internal readonly List<string> Lines = new List<string>();

        internal void LogInfo(string m) { Lines.Add("INFO " + m); Console.WriteLine("  [INFO] " + m); }
        internal void LogWarning(string m) { Lines.Add("WARN " + m); Console.WriteLine("  [WARN] " + m); }
        internal void LogError(string m) { Lines.Add("ERR " + m); Console.WriteLine("  [ERR ] " + m); }
    }

    internal static class RareShopPlugin
    {
        internal static readonly StubLog Log = new StubLog();
    }

    internal static class RarityPalette
    {
        internal const int MinTier = 1;
        internal const int MaxTier = 5;
    }
}

namespace TierTest
{
    internal static class Program
    {
        private static int _failures;

        private static void Check(bool ok, string what)
        {
            Console.WriteLine((ok ? "  ok   " : "  FAIL ") + what);
            if (!ok)
            {
                _failures++;
            }
        }

        private static int Main(string[] args)
        {
            if (args.Length < 2)
            {
                Console.Error.WriteLine("usage: TierTest <configDirWithCsv> <catalogJson>");
                return 2;
            }

            BepInEx.Paths.ConfigPath = args[0];
            string catalogJson = args[1];

            Console.WriteLine("== loading the real ItemTiers parser from " + args[0] + " ==");
            NightRaider.RareShop.ItemTiers.Load();

            int mapped = NightRaider.RareShop.ItemTiers.Count;
            Console.WriteLine();
            Console.WriteLine("== assertions ==");
            Check(mapped > 0, "table loaded at all (mapped " + mapped + " items)");
            Check(NightRaider.RareShop.ItemTiers.SourcePath != null, "source path reported");

            // 1. every row of the shipped table must survive parsing, with nothing skipped.
            string log = string.Join("\n", NightRaider.RareShop.RareShopPlugin.Log.Lines);
            Check(!log.Contains("跳过"), "no malformed rows skipped");

            // 2. every model id in the catalog must be mapped, and mapped to 1..5.
            string raw = System.IO.File.ReadAllText(catalogJson, System.Text.Encoding.UTF8);
            var ids = new List<int>();
            foreach (System.Text.RegularExpressions.Match m in
                     System.Text.RegularExpressions.Regex.Matches(raw, "\"modelId\":\\s*(\\d+)"))
            {
                ids.Add(int.Parse(m.Groups[1].Value));
            }
            Console.WriteLine("  catalog ids = " + ids.Count);

            int missing = 0;
            int outOfRange = 0;
            var missingIds = new System.Collections.Generic.HashSet<int>();
            var histogram = new Dictionary<int, int>();
            foreach (int id in ids)
            {
                int tier = NightRaider.RareShop.ItemTiers.TierOf(id);
                if (tier == 0)
                {
                    missing++;
                    missingIds.Add(id);
                    continue;
                }
                if (tier < 1 || tier > 5)
                {
                    outOfRange++;
                }
                if (!histogram.ContainsKey(tier))
                {
                    histogram[tier] = 0;
                }
                histogram[tier]++;
            }
            // 2b. rows with tier = 0 are the hand-assignment list: they must NOT be mapped,
            //     so that TierOf returns 0 and the mod keeps the game's own colour. Note that
            //     Export-Csv quotes every field, hence the optional quotes.
            var pendingIds = new System.Collections.Generic.HashSet<int>();
            string[] csvLines = System.IO.File.ReadAllLines(
                System.IO.Path.Combine(args[0], "NightRaider_item_tiers.csv"), System.Text.Encoding.UTF8);
            for (int i = 1; i < csvLines.Length; i++)
            {
                System.Text.RegularExpressions.Match mm =
                    System.Text.RegularExpressions.Regex.Match(csvLines[i], "^\"?(\\d+)\"?,\"?(-?\\d+)\"?,");
                if (mm.Success && int.Parse(mm.Groups[2].Value) <= 0)
                {
                    pendingIds.Add(int.Parse(mm.Groups[1].Value));
                }
            }
            Console.WriteLine("  distinct pending ids in csv = " + pendingIds.Count);
            Console.WriteLine("  unmapped id occurrences = " + missing + ", distinct = " + missingIds.Count);
            Check(missingIds.Count == pendingIds.Count,
                "distinct unmapped ids == pending ids (" + missingIds.Count + " vs " + pendingIds.Count + ")");
            bool sameSet = missingIds.SetEquals(pendingIds);
            Check(sameSet, "the unmapped set is exactly the pending set");
            Check(NightRaider.RareShop.ItemTiers.TierOf(1111) == 5,
                "hand-assigned id 1111 -> tier 5");

            Check(outOfRange == 0, "every tier is within 1..5");

            Console.Write("  distribution:");
            for (int t = 1; t <= 5; t++)
            {
                int n;
                histogram.TryGetValue(t, out n);
                Console.Write("  T" + t + "=" + n);
            }
            Console.WriteLine();

            // 3. ids absent from the table must report 0 ("unknown"), not a default tier,
            //    because 0 is what makes the mod keep the game's own colour.
            Check(NightRaider.RareShop.ItemTiers.TierOf(999999) == 0, "unknown id -> tier 0");

            // 4. spot checks. These are the values the drop-mechanics generator produces:
            //    reference E=5 (default settings, lowest map), spawn percentile per category,
            //    price only as an outlier correction.
            var spot = new Dictionary<int, int>
            {
                { 1000, 1 },    // KL-7, starter weapon, NPC gun-shop pool -> price tier
                { 1058, 1 },    // kitchen knife, 273 GP
                { 1111, 5 },    // K-418 Zavier: hand-assigned (never drops, not craftable)
                // Both of these are the dearest AMMO in the game (1680 and 1500 GP) and the
                // blend rates them rare, but the absolute-price ceiling caps anything under
                // 2000 GP at tier 3. That is the point of the ceiling: no AMMO can ever be
                // "legendary" just for being the priciest ammo in a cheap category, so the
                // whole AMMO category tops out at tier 3.
                { 4701, 3 },    // frag grenade, 1680 GP -> blend/price tier 5, capped to 3
                { 4033, 3 },    // RPG HE ammo, 1500 GP -> blend score 0.9, capped to 3
                { 4750, 5 },    // golden mask, 357800
                { 4383, 1 },    // silver necklace, common travel-box treasure
                { 5000, 1 },    // simple helmet, workbench chain level 0 -> 1
                { 5003, 5 },    // special helmet, workbench chain level 3 -> 5
                { 4624, 1 },    // simple backpack, chain step 1
                { 4622, 2 },    // 警用枪袋: explicit override to tier 2 (renders green);
                                // the computed tier was 4, which inverted against the dearer
                                // 4623 专业枪支保险箱 (36800 GP, tier 3)
                { 4628, 5 },    // expanded backpack, chain step 5
                { 4590, 1 },    // plastic junk, the most common item in the game
                { 4717, 4 },    // quest item, forced to 4
                { 4722, 4 },    // quest item NOT in the pending list, also forced to 4
            };
            foreach (var kv in spot)
            {
                int got = NightRaider.RareShop.ItemTiers.TierOf(kv.Key);
                Check(got == kv.Value, "id " + kv.Key + " -> tier " + got + " (expected " + kv.Value + ")");
            }

            // 5. the loader must survive a second call (the mod reloads on every F8 press).
            NightRaider.RareShop.ItemTiers.Reload();
            Check(NightRaider.RareShop.ItemTiers.Count == mapped, "reload is idempotent");

            Console.WriteLine();
            Console.WriteLine(_failures == 0 ? "ALL CHECKS PASSED" : _failures + " CHECK(S) FAILED");
            return _failures == 0 ? 0 : 1;
        }
    }
}
