# Computes the loot pool ("tier") probabilities of BuildingControl.GetBagContent.
#
# Background: every threshold in the pool-selection ladders has the shape
#     BASE - num2 - ManagerBase<TerrainManager>.Instance.hardCode
# so a ladder's branch probabilities depend only on the single effective value
#     E = num2 + hardCode
# Lottery(p) is true with probability min(1, p/100), because the roll is Random.Range(0,100) = 0..99.
#
# This script takes the TOP-LEVEL ladder of each per-item `for` loop. Containers whose ladder
# branches contain their own nested ladders are flagged (the nested split is a sub-decision
# inside one pool, not another tier of the same ladder).

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$lines = Get-Content (Join-Path $root 'game_src\BuildingControl.cs') -Encoding UTF8

$start = -1
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match '^\tpublic void GetBagContent\(\)') { $start = $i; break }
}
$end = $lines.Count
for ($i = $start + 1; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match '^\t(public|private|protected)\s') { $end = $i; break }
}

function Get-Indent([string]$s) {
    $n = 0
    while ($n -lt $s.Length -and $s[$n] -eq "`t") { $n++ }
    return $n
}

# --- collect the top-level ladder inside every for-loop body ------------------
$ladders = New-Object System.Collections.ArrayList
$case = 0
$i = $start
while ($i -lt $end) {
    $t = $lines[$i].Trim()
    if ($t -match '^case (\d+):') { $case = [int]$Matches[1]; $i++; continue }

    if ($t -match '^for \(') {
        $forIndent = Get-Indent $lines[$i]
        $bodyIndent = $forIndent + 1
        $j = $i + 1
        # skip the opening brace line
        while ($j -lt $end -and $lines[$j].Trim() -eq '') { $j++ }
        if ($j -lt $end -and $lines[$j].Trim() -eq '{') { $j++ }

        # first statement at body indent
        while ($j -lt $end -and ($lines[$j].Trim() -eq '' -or (Get-Indent $lines[$j]) -gt $bodyIndent)) {
            if ((Get-Indent $lines[$j]) -lt $bodyIndent) { break }
            $j++
        }

        if ($j -lt $end -and (Get-Indent $lines[$j]) -eq $bodyIndent) {
            $bt = $lines[$j].Trim()
            if ($bt -match '^if \(ToolManager\.Lottery\((.+)\)\)$') {
                $thr = @($Matches[1])
                $pools = @('')
                $nested = $false
                $branch = 0
                # Track brace depth so that the '}' closing a branch block is not mistaken
                # for the '}' closing the whole for-body. The ladder continues only while
                # depth is back to 0.
                $depth = 0
                $k = $j + 1
                while ($k -lt $end) {
                    $kt = $lines[$k].Trim()
                    if ($kt -eq '') { $k++; continue }
                    if ($kt -eq '{') { $depth++; $k++; continue }
                    if ($kt -eq '}') {
                        $depth--
                        if ($depth -lt 0) { break }
                        $k++
                        continue
                    }
                    if ($depth -eq 0) {
                        if ($kt -match '^else if \(ToolManager\.Lottery\((.+)\)\)$') {
                            $thr += $Matches[1]; $pools += ''; $branch = $thr.Count - 1; $k++; continue
                        }
                        if ($kt -eq 'else') {
                            $thr += 'ELSE'; $pools += ''; $branch = $thr.Count - 1; $k++; continue
                        }
                        break
                    }
                    # depth >= 1: inside the current branch, look for the pool it draws from
                    if ($pools[$branch] -eq '') {
                        if ($kt -match 'GetSingleRandomCount\(ManagerBase<DataHub>\.Instance\.(\w+)\)') {
                            $pools[$branch] = $Matches[1]
                        }
                        elseif ($kt -match 'ManagerBase<DataHub>\.Instance\.(\w+)') {
                            $pools[$branch] = $Matches[1]
                        }
                    }
                    if ($kt -match '^if \(ToolManager\.Lottery\(' -or $kt -match '^else if \(ToolManager\.Lottery\(') { $nested = $true }
                    $k++
                }
                [void]$ladders.Add([pscustomobject]@{
                        Case = $case; Line = $j + 1; Thr = $thr; Pools = $pools; Nested = $nested
                        Loop = $lines[$i].Trim()
                    })
            }
        }
        $i = $j
        continue
    }
    $i++
}

Write-Host ("top-level ladders found: {0}" -f $ladders.Count)

function Get-Sig([string]$e) {
    $x = $e.Trim()
    if ($x -eq 'ELSE') { return 'ELSE' }
    if ($x -match '^(\d+)\s*-\s*num2\s*-\s*ManagerBase<TerrainManager>\.Instance\.hardCode$') { return 'E:' + $Matches[1] }
    if ($x -match '^(\d+)\s*-\s*num2$') { return 'N:' + $Matches[1] }
    if ($x -match '^(\d+)\s*-\s*ManagerBase<TerrainManager>\.Instance\.hardCode$') { return 'H:' + $Matches[1] }
    if ($x -match '^(\d+)$') { return 'C:' + $Matches[1] }
    if ($x -match '^(\d+)\s*\+\s*ManagerBase<TerrainManager>\.Instance\.hardCode$') { return 'P:' + $Matches[1] }
    if ($x -match '^ManagerBase<TerrainManager>\.Instance\.hardCode$') { return 'H:0' }
    return 'X:' + $x
}

$shapes = @{}
foreach ($l in $ladders) {
    $kinds = @()
    $bases = @()
    $ok = $true
    foreach ($t in $l.Thr) {
        $s = Get-Sig $t
        if ($s -eq 'ELSE') { $kinds += 'ELSE'; $bases += 0; continue }
        if ($s -match '^X:') { $ok = $false; $kinds += 'X'; $bases += 0; continue }
        $k, $b = $s.Split(':')
        $kinds += $k
        $bases += [double]$b
    }
    # Signature must include the bases, otherwise ladders that differ only in their
    # numeric thresholds would be merged into one row.
    $sigParts = @()
    for ($z = 0; $z -lt $kinds.Count; $z++) {
        if ($kinds[$z] -eq 'ELSE') { $sigParts += 'ELSE'; continue }
        $sigParts += ('{0}:{1}' -f $kinds[$z], $bases[$z])
    }
    $sig = ($sigParts -join ' | ')
    if (-not $shapes.ContainsKey($sig)) {
        $shapes[$sig] = [pscustomobject]@{
            Sig = $sig; N = 0; Kinds = $kinds; Bases = $bases; Ok = $ok
            Pools = $l.Pools
            Cases = (New-Object System.Collections.ArrayList); Nested = $false
        }
    }
    $shapes[$sig].N++
    if ($l.Nested) { $shapes[$sig].Nested = $true }
    if ($shapes[$sig].Cases.Count -lt 14 -and -not $shapes[$sig].Cases.Contains($l.Case)) {
        [void]$shapes[$sig].Cases.Add($l.Case)
    }
}

function Format-Shape($kinds, $bases) {
    $parts = @()
    for ($k = 0; $k -lt $kinds.Count; $k++) {
        if ($kinds[$k] -eq 'ELSE') { $parts += 'ELSE'; continue }
        $parts += ('{0}:{1}' -f $kinds[$k], $bases[$k])
    }
    return ($parts -join ' | ')
}

Write-Host ''
Write-Host '=== distinct top-level ladder shapes (n = how many for-loops use it) ==='
$shapes.Values | Sort-Object N -Descending | ForEach-Object {
    $nest = if ($_.Nested) { ' [has nested sub-ladder]' } else { '' }
    $note = if (-not $_.Ok) { ' [unparsed term - numbers omitted]' } else { '' }
    Write-Host ("  n={0,-3} myID=[{1}]{2}{3}" -f $_.N, ($_.Cases -join ','), $nest, $note)
    Write-Host ("         {0}" -f (Format-Shape $_.Kinds $_.Bases))
}

# --- probabilities -----------------------------------------------------------
# Lottery(p) is true with probability min(1, p/100).
#   E:kind  threshold = base - E          (E = num2 + hardCode)
#   N:kind  threshold = base              (independent of difficulty)
#   H:kind  threshold = base - hardCode
#   C:kind  threshold = base              (constant)
function Get-Probs($kinds, $bases, [int]$E, [int]$H) {
    $out = @()
    $rem = 1.0
    for ($k = 0; $k -lt $kinds.Count; $k++) {
        if ($kinds[$k] -eq 'ELSE') { $out += $rem; $rem = 0.0; continue }
        $b = $bases[$k]
        switch ($kinds[$k]) {
            'E' { $thr = $b - $E }
            'N' { $thr = $b }
            'H' { $thr = $b - $H }
            'C' { $thr = $b }
            default { $thr = $b }
        }
        if ($thr -gt 100) { $thr = 100 }
        if ($thr -lt 0) { $thr = 0 }
        $hit = $rem * ($thr / 100.0)
        $out += $hit
        $rem -= $hit
    }
    if ($rem -gt 1e-12) { $out += $rem }   # ladder with no final else
    return , $out
}

$pick = $shapes.Values | Where-Object { $_.Ok } | Sort-Object N -Descending | Select-Object -First 6

# --- E lookup table ----------------------------------------------------------
# num2 = 1
#      + (hardCode > 4 ? -1 : 0)
#      + (cuisine 213 ? 2 : 0)
#      + skill 80104 (0..4)
#      + boxBonus   boxBonus = (boxLevel <= 0 || boxLevel >= 4) ? 4 : boxLevel
#      + GetLootRateByHard()      hardCoreDic[8]: 1->+5 2->+2 3->0 4->-1 5->-2
#      + (anniversary 1/27..2/9 ? 2 : 0)
# E = num2 + hardCode
$lootRate = @{ 1 = 5; 2 = 2; 3 = 0; 4 = -1; 5 = -2 }
Write-Host ''
Write-Host '=== E lookup: plain container (boxLevel<=0 -> boxBonus 4), no skill / cuisine / event ==='
Write-Host '    rows = map difficulty hardCode, cols = the "搜刮资源难度" setting (hardCoreDic[8])'
$hdr = '  hardCode |'
foreach ($s in 1, 2, 3, 4, 5) { $hdr += (' set' + $s).PadLeft(8) }
Write-Host $hdr
foreach ($hc in 0, 1, 2, 3, 4, 5) {
    $row = '     {0}     |' -f $hc
    foreach ($s in 1, 2, 3, 4, 5) {
        $num2 = 1 + $(if ($hc -gt 4) { -1 } else { 0 }) + 4 + $lootRate[$s]
        $row += ('{0,8}' -f ($num2 + $hc))
    }
    Write-Host $row
}
Write-Host '    each +1 of: skill 80104 (max +4), cuisine 213 (+2), anniversary event (+2)'
Write-Host '    boxBonus is 4 for boxLevel 0 or >=4, otherwise boxLevel itself (1..3 -> E drops by 1..3)'

Write-Host '    Branch percentages are shown per ladder step; the "distinct pool" block'
Write-Host '    merges steps that draw from the SAME pool, which is the number that matters.'
foreach ($s in $pick) {
    Write-Host ''
    Write-Host ('  ' + (Format-Shape $s.Kinds $s.Bases) + '   (n=' + $s.N + ', myID ' + ($s.Cases -join ',') + ')')
    $hdr = '   E  |'
    for ($k = 1; $k -le $s.Kinds.Count; $k++) { $hdr += ('step' + $k).PadLeft(26) }
    Write-Host $hdr
    $nameRow = '      |'
    foreach ($p in $s.Pools) { $nameRow += (' ' + $p).PadRight(26) }
    Write-Host $nameRow
    foreach ($E in 3, 5, 7, 8, 10, 12, 14, 18, 22) {
        $pr = Get-Probs $s.Kinds $s.Bases $E 3
        $row = '  {0,2}  |' -f $E
        foreach ($v in $pr) { $row += ('{0,25:F2}%' -f ($v * 100)) }
        Write-Host $row
    }

    # merge steps that share a pool
    $byPool = [ordered]@{}
    $pr = Get-Probs $s.Kinds $s.Bases 0 3
    for ($k = 0; $k -lt $s.Pools.Count; $k++) {
        $p = $s.Pools[$k]
        if (-not $byPool.Contains($p)) { $byPool[$p] = 0.0 }
    }
    Write-Host '      distinct pools:'
    foreach ($E in 3, 5, 7, 8, 10, 12, 14, 18, 22) {
        foreach ($p in @($byPool.Keys)) { $byPool[$p] = 0.0 }
        $pr = Get-Probs $s.Kinds $s.Bases $E 3
        for ($k = 0; $k -lt $s.Pools.Count; $k++) {
            if ($k -lt $pr.Count) { $byPool[$s.Pools[$k]] += $pr[$k] }
        }
        $cells = @()
        foreach ($p in @($byPool.Keys)) { $cells += ('{0}={1:F2}%' -f $p, ($byPool[$p] * 100)) }
        Write-Host ('        E={0,2}: {1}' -f $E, ($cells -join '  '))
    }
}
