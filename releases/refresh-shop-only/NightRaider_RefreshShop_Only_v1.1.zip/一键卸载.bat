﻿@echo off
chcp 65001 >nul
title Night Raider 刷新商店(F7) - 一键卸载
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
