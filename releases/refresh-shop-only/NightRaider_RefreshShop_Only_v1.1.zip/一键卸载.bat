﻿@echo off
chcp 65001 >nul
title Night Raider 刷新商店(F7) - 一键卸载
setlocal

echo.
echo   正在启动卸载程序...
echo.

set "PSEXE="
if exist "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" set "PSEXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not defined PSEXE where powershell >nul 2>nul && set "PSEXE=powershell"

if not defined PSEXE goto nops
if not exist "%~dp0uninstall.ps1" goto nofile

"%PSEXE%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" goto failed
echo   卸载程序已结束。
goto done

:failed
echo   ============================================================
echo    卸载程序异常结束（退出码 %RC%）
echo   ============================================================
echo.
echo   请把上面窗口里的内容截图反馈。
goto done

:nops
echo   [错误] 在这台电脑上找不到 PowerShell，无法自动卸载。
echo.
echo   请手动删除这两个文件即可卸载：
echo      BepInEx\plugins\NightRaider.RareRefresh.dll
echo      BepInEx\config\nightraider.rarerefresh.cfg
goto done

:nofile
echo   [错误] 找不到 uninstall.ps1。
echo.
echo   请把整个压缩包【完整解压】到一个文件夹后再运行本程序。
goto done

:done
echo.
echo   按任意键关闭本窗口...
pause >nul
endlocal
