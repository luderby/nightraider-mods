﻿@echo off
chcp 65001 >nul
title Night Raider 刷新商店(F7) - 一键安装
setlocal

echo.
echo   正在启动安装程序...
echo.

set "PSEXE="
if exist "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" set "PSEXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not defined PSEXE where powershell >nul 2>nul && set "PSEXE=powershell"

if not defined PSEXE goto nops
if not exist "%~dp0install.ps1" goto nofile

"%PSEXE%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" goto failed
echo   安装程序已结束。若安装成功，进游戏按 F7 即可。
goto done

:failed
echo   ============================================================
echo    安装程序异常结束（退出码 %RC%）
echo   ============================================================
echo.
echo   请把上面窗口里的内容截图反馈，特别是红色的文字。
goto done

:nops
echo   [错误] 在这台电脑上找不到 PowerShell，无法自动安装。
echo.
echo   请改用「手动安装」：
echo     1) 打开压缩包里的 BepInEx 文件夹
echo     2) 把 plugins 和 config 两个文件夹里的内容
echo        复制到游戏的 BepInEx 对应文件夹
echo   详见「① 先看我 - 安装说明.txt」。
goto done

:nofile
echo   [错误] 找不到 install.ps1。
echo.
echo   请把整个压缩包【完整解压】到一个文件夹后再运行本程序，
echo   不要在压缩软件里直接双击运行。
goto done

:done
echo.
echo   按任意键关闭本窗口...
pause >nul
endlocal
