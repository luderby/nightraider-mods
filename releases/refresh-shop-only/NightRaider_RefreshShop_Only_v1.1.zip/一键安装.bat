﻿@echo off
chcp 65001 >nul
title Night Raider 刷新商店(F7) - 一键安装
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
