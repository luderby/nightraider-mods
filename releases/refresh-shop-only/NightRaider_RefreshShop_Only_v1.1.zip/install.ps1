﻿# =====================================================================
#  Night Raider 刷新商店（F7）——  一键安装
#
#  这个包只安装 1 个 MOD：
#      NightRaider.RareRefresh.dll     （F7 刷新商店）
#
#  它不带「物品稀有度底色」，也不带「物品商店」。
#
#  设计目标：装了它之后，你以后还可以再装别的 MOD，不会冲突。
#  做法是「缺什么补什么，绝不覆盖已有的东西」：
#
#      已经有的文件                    本程序的处理
#      ------------------------------  ----------------------------------
#      winhttp.dll / doorstop / core   已有就【原样跳过】，绝不覆盖
#      BepInEx\plugins\*.dll           只往里【新增】本 MOD 的文件
#      NightRaider_item_tiers.csv      已有就跳过（别的 MOD 的表优先）
#      刷新商店自己（重复安装）        只在版本不同时更新，并先备份旧的
#      同名文件被本程序覆盖的          一律先备份，可完整还原
#
#  所以和别的 MOD 不会互相踩：每个 MOD 有自己的 dll 文件名，
#  而共用的 BepInEx 运行库不会被第二次安装动到。
# =====================================================================

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

$pkgRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

function Say  ($m) { Write-Host $m }
function Ok   ($m) { Write-Host $m -ForegroundColor Green }
function Warn ($m) { Write-Host $m -ForegroundColor Yellow }
function Bad  ($m) { Write-Host $m -ForegroundColor Red }
function Line ()   { Write-Host ('-' * 64) -ForegroundColor DarkGray }

Say ''
Say '==============================================================' -ForegroundColor Cyan
Say '     Night Raider 刷新商店（F7）   v1.1   一键安装' -ForegroundColor Cyan
Say '     Refresh Shop only  -  no item tint  (BepInEx)' -ForegroundColor Cyan
Say '==============================================================' -ForegroundColor Cyan
Say ''
Say '  这个包只装 1 个功能：刷新商店（游戏内按 F7）。'
Say '  不含「物品稀有度底色」，不会给物品格子加颜色。'
Say ''
Say '  如果你之前装过别的 MOD：本程序会自动识别，只补上缺的部分，'
Say '  不会覆盖你已有的 BepInEx 运行库，也不会动别的 MOD。'
Say ''
Say '  安装前会自动备份，可随时用「一键卸载.bat」还原。'
Say ''
Say '  注意：本 MOD 与「物品底色」是各自独立的功能。'
Say '  如果你之后又装了底色 MOD，底色由那个 MOD 负责，两者不冲突。'
Say ''
Read-Host '  准备好后按回车开始（直接关窗口 = 取消）'

# ---------------------------------------------------------------- 校验包完整
Line
Say '[1/6] 检查安装包是否完整 ...'

$mustHave = @(
    'winhttp.dll',
    'doorstop_config.ini',
    '.doorstop_version',
    'BepInEx\core\BepInEx.dll',
    'BepInEx\core\0Harmony.dll',
    'BepInEx\plugins\NightRaider.RareRefresh.dll',
    'BepInEx\plugins\NightRaider_item_tiers.csv'
)
$missing = @()
foreach ($f in $mustHave) {
    if (-not (Test-Path -LiteralPath (Join-Path $pkgRoot $f))) { $missing += $f }
}
if ($missing.Count -gt 0) {
    Bad '  安装包不完整，缺少以下文件：'
    foreach ($f in $missing) { Bad ('    ' + $f) }
    Say ''
    Warn '  请重新解压压缩包（不要只解压一部分文件），然后重试。'
    Say ''
    Read-Host '  按回车退出'
    exit 1
}
Ok '  安装包完整（只有刷新商店这 1 个 MOD）。'

# ---------------------------------------------------------------- 找游戏目录
Line
Say '[2/6] 正在自动查找游戏目录 ...'

function Test-GameDir([string]$p) {
    if ([string]::IsNullOrWhiteSpace($p)) { return $false }
    if (-not (Test-Path -LiteralPath $p)) { return $false }
    if (-not (Test-Path -LiteralPath (Join-Path $p 'NightRaider.exe'))) { return $false }
    # Unity 游戏本体的标志，用它确认没装错到别的同名文件夹
    if (-not (Test-Path -LiteralPath (Join-Path $p 'NightRaider_Data\Managed\Assembly-CSharp.dll'))) { return $false }
    return $true
}

$candidates = New-Object System.Collections.ArrayList

# a) Steam 安装位置（注册表）
$steam = $null
try { $steam = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -Name SteamPath -ErrorAction Stop).SteamPath } catch { }
if (-not $steam) {
    try { $steam = (Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam' -Name InstallPath -ErrorAction Stop).InstallPath } catch { }
}
if ($steam) {
    $steam = $steam -replace '/', '\'
    [void]$candidates.Add((Join-Path $steam 'steamapps\common\Night Raider\NightRaider'))

    # b) 其他 Steam 库（libraryfolders.vdf）
    $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
    if (Test-Path -LiteralPath $vdf) {
        try {
            $raw = Get-Content -LiteralPath $vdf -Raw
            foreach ($m in [regex]::Matches($raw, '"path"\s+"(.+?)"')) {
                $lib = $m.Groups[1].Value -replace '\\\\', '\'
                [void]$candidates.Add((Join-Path $lib 'steamapps\common\Night Raider\NightRaider'))
            }
        }
        catch { }
    }
}

# c) 各盘符的常见位置
$subs = @(
    'steamapps\common\Night Raider\NightRaider',
    'SteamLibrary\steamapps\common\Night Raider\NightRaider',
    'Steam\steamapps\common\Night Raider\NightRaider',
    'Program Files (x86)\Steam\steamapps\common\Night Raider\NightRaider',
    'Program Files\Steam\steamapps\common\Night Raider\NightRaider',
    'Games\Steam\steamapps\common\Night Raider\NightRaider'
)
foreach ($drv in (Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
    foreach ($s in $subs) {
        [void]$candidates.Add((Join-Path $drv.Root $s))
    }
}

$game = $null
foreach ($c in $candidates) {
    if (Test-GameDir $c) { $game = (Resolve-Path -LiteralPath $c).Path; break }
}

# d) 找不到就请用户手动给（支持把文件夹拖进窗口）
while (-not $game) {
    Say ''
    Warn '  没有自动找到游戏目录。'
    Say ''
    Say '  请手动指定：打开 Steam → 库 → 右键「Night Raider」→ 管理 → 浏览本地文件，'
    Say '  然后把打开的文件夹直接拖到这个窗口里，再按回车。'
    Say ''
    Say '  （要选的是里面有 NightRaider.exe 的那一层，通常是 ...\common\Night Raider\NightRaider）'
    Say ''
    $typed = Read-Host '  游戏目录'
    if ([string]::IsNullOrWhiteSpace($typed)) { continue }
    $typed = $typed.Trim().Trim('"').Trim()
    if (Test-GameDir $typed) {
        $game = (Resolve-Path -LiteralPath $typed).Path
    }
    else {
        Bad '  这个目录看起来不是 Night Raider 的游戏目录（没找到 NightRaider.exe）。'
        Say '  请再试一次，或关掉窗口取消安装。'
    }
}

Ok ('  已找到游戏目录：' + $game)

# 记下安装位置，供「一键卸载.bat」使用
try { Set-Content -LiteralPath (Join-Path $pkgRoot '_上次安装的目录.txt') -Value $game -Encoding UTF8 } catch { }

# ---------------------------------------------------------------- 游戏是否在跑
Line
Say '[3/6] 检查游戏是否正在运行 ...'

$running = @(Get-Process -Name 'NightRaider' -ErrorAction SilentlyContinue)
if ($running.Count -gt 0) {
    Bad '  检测到游戏正在运行！'
    Say ''
    Say '  请先完全退出游戏（Steam 里点“停止”，确认任务栏/托盘里也没有了），'
    Say '  然后重新运行本安装程序。'
    Say ''
    Read-Host '  按回车退出'
    exit 1
}
Ok '  游戏未运行，可以安全安装。'

# ---------------------------------------------------------------- 检测已有 MOD
Line
Say '[4/6] 检查游戏里已有哪些 MOD ...'

$gameBep    = Join-Path $game 'BepInEx'
$gameCore   = Join-Path $game 'BepInEx\core'
$gamePlugin = Join-Path $game 'BepInEx\plugins'
$gameConfig = Join-Path $game 'BepInEx\config'

$hasLoader = (Test-Path -LiteralPath (Join-Path $game 'winhttp.dll')) -and
             (Test-Path -LiteralPath (Join-Path $gameCore 'BepInEx.dll'))

$existingPlugins = @()
if (Test-Path -LiteralPath $gamePlugin) {
    $existingPlugins = @(Get-ChildItem -LiteralPath $gamePlugin -File -Filter '*.dll' -ErrorAction SilentlyContinue)
}

$mode = ''
if ($hasLoader) {
    $mode = 'addon'
    Ok '  检测到游戏已经装过 MOD（BepInEx 已在）。'
    Say '  → 本程序会【保留你现有的一切】，只新增刷新商店这 1 个 MOD。'
    Say '  → 不会覆盖 winhttp.dll / BepInEx\core 运行库，也不会动别的插件。'
    if ($existingPlugins.Count -gt 0) {
        Say ''
        Say ('  已有的插件（共 ' + $existingPlugins.Count + ' 个，本程序不会改动它们）：')
        foreach ($p in $existingPlugins) { Say ('      ' + $p.Name) }
    }
}
else {
    $mode = 'full'
    Ok '  检测到游戏还没有装过 MOD。'
    Say '  → 本程序会连同 BepInEx 运行库一起装好，装完即可用。'
}

# 同名文件（本 MOD 自己）的特殊处理
$selfDll  = Join-Path $gamePlugin 'NightRaider.RareRefresh.dll'
$selfOld  = Test-Path -LiteralPath $selfDll
if ($selfOld) {
    Say ''
    Warn '  注意：游戏里已经有 NightRaider.RareRefresh.dll（刷新商店）。'
    Warn '  本程序会先把它备份，再更新为随包版本（v1.1.0）。'
    Warn '  如果你现在用着没问题、不想更新，直接关窗口即可取消。'
    Say ''
    Read-Host '  要继续更新吗？按回车继续，或关窗口取消'
}

# 悬停提示：本包不含底色，若已装底色则说明一下
$tintDll = Join-Path $gamePlugin 'NightRaider.RareTint.dll'
if (Test-Path -LiteralPath $tintDll) {
    Say ''
    Say '  说明：检测到 NightRaider.RareTint.dll（物品稀有度底色）。'
    Say '  它和刷新商店互不影响 —— 底色由它负责，本包不会改它。'
}

# ---------------------------------------------------------------- 备份
Line
Say '[5/6] 备份将要改动的文件 ...'

$stamp  = Get-Date -Format 'yyyyMMdd-HHmmss'
$backup = Join-Path $game ('_MOD备份_' + $stamp)
$saved  = New-Object System.Collections.ArrayList
New-Item -ItemType Directory -Force -Path $backup | Out-Null

function Save-One([string]$rel) {
    $src = Join-Path $game $rel
    if (-not (Test-Path -LiteralPath $src)) { return $false }
    $dst = Join-Path $backup $rel
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
    Copy-Item -LiteralPath $src -Destination $dst -Force
    [void]$saved.Add($rel)
    return $true
}

if ($mode -eq 'full') {
    # 全新安装：备份加载器文件（万一用户其实装过但被删了一半）
    foreach ($f in 'winhttp.dll', 'doorstop_config.ini', '.doorstop_version') { [void](Save-One $f) }
}
# 无论如何，本 MOD 自己的同名文件和将要新增的表都要能还原
[void](Save-One 'BepInEx\plugins\NightRaider.RareRefresh.dll')
[void](Save-One 'BepInEx\plugins\NightRaider_item_tiers.csv')
[void](Save-One 'BepInEx\config\NightRaider_item_tiers.csv')
[void](Save-One 'BepInEx\config\nightraider.rarerefresh.cfg')

if ($saved.Count -gt 0) {
    Ok ('  已备份 ' + $saved.Count + ' 个原有文件到：' + $backup)
    Say '  （想还原就运行「一键卸载.bat」）'
}
else {
    Say '  没有需要备份的原有文件（全新安装）。'
    Remove-Item -LiteralPath $backup -Force -Recurse -ErrorAction SilentlyContinue
    $backup = $null
}

# ---------------------------------------------------------------- 复制
Line
Say '[6/6] 正在安装 ...'

$installed = New-Object System.Collections.ArrayList

# 1) 加载器 + 运行库：只在「全新安装」时写，已有就一个字节都不动
if ($mode -eq 'full') {
    foreach ($f in 'winhttp.dll', 'doorstop_config.ini', '.doorstop_version') {
        Copy-Item -LiteralPath (Join-Path $pkgRoot $f) -Destination $game -Force
        Say ('  + ' + $f)
    }
    # Copy-Item 的坑：目标目录不存在时，它会把源目录的内容直接倒进目标，
    # 而不是在目标下再建一层。所以必须先建好 BepInEx\，才能得到 BepInEx\core\。
    New-Item -ItemType Directory -Force -Path $gameBep | Out-Null
    Copy-Item -LiteralPath (Join-Path $pkgRoot 'BepInEx\core') -Destination $gameBep -Recurse -Force
    Say '  + BepInEx\core\   （运行库，共 18 个文件）'
}
else {
    Say '  = winhttp.dll / BepInEx\core\   已有，原样保留（未改动）'
}

# 2) 刷新商店插件
New-Item -ItemType Directory -Force -Path $gamePlugin | Out-Null
Copy-Item -LiteralPath (Join-Path $pkgRoot 'BepInEx\plugins\NightRaider.RareRefresh.dll') -Destination $gamePlugin -Force
[void]$installed.Add('BepInEx\plugins\NightRaider.RareRefresh.dll')
Say '  + BepInEx\plugins\NightRaider.RareRefresh.dll   （F7 刷新商店）'

# 3) 稀有度表：已有就不覆盖，避免把别的 MOD 或用户改过的表冲掉
$tierPlugin = Join-Path $gamePlugin 'NightRaider_item_tiers.csv'
$tierConfig = Join-Path $gameConfig 'NightRaider_item_tiers.csv'
$tierExisted = (Test-Path -LiteralPath $tierPlugin) -or (Test-Path -LiteralPath $tierConfig)

if ($tierExisted) {
    Say '  = NightRaider_item_tiers.csv   已有，原样保留（未改动）'
}
else {
    New-Item -ItemType Directory -Force -Path $gameConfig | Out-Null
    Copy-Item -LiteralPath (Join-Path $pkgRoot 'BepInEx\plugins\NightRaider_item_tiers.csv') -Destination $tierPlugin -Force
    Copy-Item -LiteralPath (Join-Path $pkgRoot 'BepInEx\config\NightRaider_item_tiers.csv')  -Destination $tierConfig -Force
    [void]$installed.Add('BepInEx\plugins\NightRaider_item_tiers.csv')
    [void]$installed.Add('BepInEx\config\NightRaider_item_tiers.csv')
    Say '  + NightRaider_item_tiers.csv   （稀有度表，plugins + config 各一份）'
}

# 4) 配置：已有就保留（用户改过的按键/费用不覆盖）
$cfgPath = Join-Path $gameConfig 'nightraider.rarerefresh.cfg'
if (Test-Path -LiteralPath $cfgPath) {
    Say '  = nightraider.rarerefresh.cfg   已有，原样保留（你的设置不会被改）'
}
else {
    New-Item -ItemType Directory -Force -Path $gameConfig | Out-Null
    # 第一次就让插件自己生成默认配置，这样默认值与代码永远一致
    [void]$installed.Add('BepInEx\config\nightraider.rarerefresh.cfg   (首次启动时自动生成)')
    Say '  · nightraider.rarerefresh.cfg   将在第一次启动游戏时自动生成（默认 F7）'
}

# ---------------------------------------------------------------- 记录清单
# 供「一键卸载.bat」精确还原；也让你知道这个包动过哪些文件
$manifest = [ordered]@{
    package        = 'NightRaider_仅刷新商店_v1.1'
    mod            = 'Night Raider Refresh Shop (F7)'
    installedAt    = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    gameDir        = $game
    mode           = $mode
    loaderWritten  = ($mode -eq 'full')
    backupDir      = $backup
    addedFiles     = @($installed)
    preservedFiles = @('winhttp.dll', 'BepInEx\core\*', 'BepInEx\plugins\*（其它 MOD）')
}
try {
    $manifest | ConvertTo-Json -Depth 4 |
        Set-Content -LiteralPath (Join-Path $gameBep '_本MOD安装记录.json') -Encoding UTF8
}
catch { }

# ---------------------------------------------------------------- 校验
$checks = @(
    'winhttp.dll',
    'BepInEx\core\BepInEx.dll',
    'BepInEx\core\0Harmony.dll',
    'BepInEx\plugins\NightRaider.RareRefresh.dll'
)
$bad = @()
foreach ($f in $checks) {
    if (-not (Test-Path -LiteralPath (Join-Path $game $f))) { $bad += $f }
}
if (-not (Test-Path -LiteralPath $tierPlugin) -and -not (Test-Path -LiteralPath $tierConfig)) {
    $bad += 'NightRaider_item_tiers.csv（稀有度表）'
}

Line
if ($bad.Count -eq 0) {
    Ok '  安装完成，全部文件校验通过！'
}
else {
    Bad '  安装似乎不完整，缺少：'
    foreach ($f in $bad) { Bad ('    ' + $f) }
    Say '  请把以上内容截图反馈。'
}

# ---------------------------------------------------------------- 结果说明
Say ''
Say '==============================================================' -ForegroundColor Cyan
if ($mode -eq 'addon') {
    Say '  安装方式：追加安装（保留了你原有的 MOD 和运行库）' -ForegroundColor Green
}
else {
    Say '  安装方式：全新安装（连 BepInEx 运行库一起装好了）' -ForegroundColor Green
}
Say '==============================================================' -ForegroundColor Cyan
Say ''
Ok '  怎么用：'
Say '      进游戏，按  F7  打开刷新商店。'
Say '      整页刷新一次 50000 GP。'
Say ''
Ok '  怎么确认装上了：'
Say '      进过一次游戏后，用记事本打开这个文件，搜索 Refresh Shop：'
Say ('          ' + (Join-Path $game 'BepInEx\LogOutput.log'))
Say '      应该能看到：  Night Raider Refresh Shop v1.1.0 已加载。开关按键: F7'
Say ''
Ok '  以后还想装别的 MOD：'
Say '      直接把别的 MOD 的文件放进 BepInEx\plugins\ 即可，不会冲突。'
Say '      如果那个 MOD 更新了 BepInEx 运行库，也随它去，本 MOD 不依赖特定版本。'
Say ''
Ok '  想卸载：'
Say '      双击「一键卸载.bat」。'
Say '      如果你本来就有别的 MOD，卸载只会拿掉刷新商店，别的 MOD 原样保留。'
Say ''
Warn '  注意：F7 刷新商店和 F8 物品商店的面板不要同时开着，会互相拦截点击。'
Say ''
Read-Host '  按回车退出'
