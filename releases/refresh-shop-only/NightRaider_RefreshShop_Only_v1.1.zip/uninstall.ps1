﻿# =====================================================================
#  Night Raider 刷新商店（F7）——  一键卸载
#
#  卸载原则：只拿掉「本包装进去的东西」，其它 MOD 一律不动。
#
#  三种情况：
#    1) 有安装记录（_本MOD安装记录.json）
#         → 精确还原：把备份里的原文件放回去，并删掉本包新增的文件
#    2) 没有记录，但有 _MOD备份_* 目录
#         → 从最近的备份里，按文件名逐个还原（不整目录删除！）
#    3) 什么都没有
#         → 只删除本包的 2 个文件，别的 MOD 保持原样
#
#  特别注意：本脚本【绝不】整目录删除 BepInEx\
#  因为那会连带删掉你之后装的其它 MOD。
# =====================================================================

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

$pkgRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

function Say  ($m) { Write-Host $m }
function Ok   ($m) { Write-Host $m -ForegroundColor Green }
function Warn ($m) { Write-Host $m -ForegroundColor Yellow }
function Bad  ($m) { Write-Host $m -ForegroundColor Red }
function Line ()   { Write-Host ('-' * 64) -ForegroundColor DarkGray }

Say ''
Say '==============================================================' -ForegroundColor Cyan
Say '     Night Raider 刷新商店（F7）   v1.1   一键卸载' -ForegroundColor Cyan
Say '==============================================================' -ForegroundColor Cyan
Say ''
Say '  只会卸载「刷新商店」。你之后装的其它 MOD 不会被碰。'
Say ''
Warn '  ！卸载前请先完全退出游戏。'
Say ''
Read-Host '  按回车开始（直接关窗口 = 取消）'

function Test-GameDir([string]$p) {
    if ([string]::IsNullOrWhiteSpace($p)) { return $false }
    if (-not (Test-Path -LiteralPath $p)) { return $false }
    if (-not (Test-Path -LiteralPath (Join-Path $p 'NightRaider.exe'))) { return $false }
    if (-not (Test-Path -LiteralPath (Join-Path $p 'NightRaider_Data\Managed\Assembly-CSharp.dll'))) { return $false }
    return $true
}

# ---------------------------------------------------------------- 找游戏目录
Line
Say '[1/2] 正在查找游戏目录 ...'

$game = $null
$record = Join-Path $pkgRoot '_上次安装的目录.txt'
if (Test-Path -LiteralPath $record) {
    $p = (Get-Content -LiteralPath $record -Raw).Trim()
    if (Test-GameDir $p) { $game = $p }
}

if (-not $game) {
    $steam = $null
    try { $steam = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -Name SteamPath -ErrorAction Stop).SteamPath } catch { }
    if ($steam) {
        $steam = $steam -replace '/', '\'
        $c = Join-Path $steam 'steamapps\common\Night Raider\NightRaider'
        if (Test-GameDir $c) { $game = $c }
        $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
        if (-not $game -and (Test-Path -LiteralPath $vdf)) {
            foreach ($m in [regex]::Matches((Get-Content -LiteralPath $vdf -Raw), '"path"\s+"(.+?)"')) {
                $lib = $m.Groups[1].Value -replace '\\\\', '\'
                $c2 = Join-Path $lib 'steamapps\common\Night Raider\NightRaider'
                if (Test-GameDir $c2) { $game = $c2; break }
            }
        }
    }
}

while (-not $game) {
    Say ''
    Say '  没找到游戏目录，请把游戏文件夹拖进本窗口后回车'
    Say '  （里面有 NightRaider.exe 的那一层）'
    Say ''
    $typed = Read-Host '  游戏目录'
    if ([string]::IsNullOrWhiteSpace($typed)) { continue }
    $typed = $typed.Trim().Trim('"').Trim()
    if (Test-GameDir $typed) { $game = (Resolve-Path -LiteralPath $typed).Path }
    else { Bad '  这不是 Night Raider 的游戏目录。' }
}
Ok ('  游戏目录：' + $game)

$running = @(Get-Process -Name 'NightRaider' -ErrorAction SilentlyContinue)
if ($running.Count -gt 0) {
    Bad '  游戏正在运行，请先完全退出再卸载。'
    Read-Host '  按回车退出'
    exit 1
}

# ---------------------------------------------------------------- 本包的文件清单
# 「独占」= 只有刷新商店会用，卸载时可以直接删
$ourOwn = @(
    'BepInEx\plugins\NightRaider.RareRefresh.dll',
    'BepInEx\config\nightraider.rarerefresh.cfg',
    'BepInEx\_本MOD安装记录.json'
)
# 「共用」= 别的 MOD（物品商店 / 物品底色）也要读这张稀有度表，
#            所以只要游戏里还有别的 MOD，就【绝不删它】——
#            删错了会让别的 MOD 一起失效。
$ourShared = @(
    'BepInEx\plugins\NightRaider_item_tiers.csv',
    'BepInEx\config\NightRaider_item_tiers.csv'
)
$ourRel = $ourOwn + $ourShared

# 游戏里还有别的 MOD 吗？（本 MOD 自己的 dll 不算）
function Test-OtherMods {
    $dir = Join-Path $game 'BepInEx\plugins'
    if (-not (Test-Path -LiteralPath $dir)) { return $false }
    $others = @(Get-ChildItem -LiteralPath $dir -File -Filter '*.dll' -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -ne 'NightRaider.RareRefresh.dll' })
    return ($others.Count -gt 0)
}

function Remove-One([string]$rel) {
    $t = Join-Path $game $rel
    if (Test-Path -LiteralPath $t) {
        try {
            Remove-Item -LiteralPath $t -Force -ErrorAction Stop
            Say ('  删除 ' + $rel)
            return $true
        }
        catch { Warn ('  删除失败（可能被占用）：' + $rel); return $false }
    }
    return $false
}

function Restore-One([string]$rel, [string]$from) {
    $src = Join-Path $from $rel
    if (-not (Test-Path -LiteralPath $src)) { return $false }
    $dst = Join-Path $game $rel
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
    Copy-Item -LiteralPath $src -Destination $dst -Force
    Say ('  还原 ' + $rel)
    return $true
}

# ---------------------------------------------------------------- 卸载
Line
Say '[2/2] 正在卸载刷新商店 ...'

# 优先读安装记录
$manifestPath = Join-Path $game 'BepInEx\_本MOD安装记录.json'
$manifest = $null
if (Test-Path -LiteralPath $manifestPath) {
    try { $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { }
}

$backupDir = $null
if ($manifest -and $manifest.backupDir) { $backupDir = $manifest.backupDir }
if (-not $backupDir -or -not (Test-Path -LiteralPath $backupDir)) {
    $cand = @(Get-ChildItem -LiteralPath $game -Directory -Filter '_MOD备份_*' -ErrorAction SilentlyContinue |
              Sort-Object Name -Descending)
    if ($cand.Count -gt 0) { $backupDir = $cand[0].FullName }
}

$changed = 0

if ($backupDir) {
    Say ('  找到备份：' + (Split-Path $backupDir -Leaf))
    Say '  → 先还原备份里属于本 MOD 的原文件'

    # 只还原本 MOD 相关的路径，绝不整目录覆盖
    foreach ($rel in $ourRel) {
        if (Restore-One $rel $backupDir) { $changed++ }
    }
    # 全新安装时写进去的加载器文件，如果在备份里就还原
    foreach ($rel in 'winhttp.dll', 'doorstop_config.ini', '.doorstop_version') {
        if (Test-Path -LiteralPath (Join-Path $backupDir $rel)) {
            if (Restore-One $rel $backupDir) { $changed++ }
        }
    }
    Say ''
    Say '  → 再清掉本包新增的文件'
}

# 删除本 MOD 的文件。
#
# 两条保护：
#   1) 备份里已经有的 → 刚还原过，保留
#   2) 共用的稀有度表 → 只要游戏里还有别的 MOD 就保留
#      （物品商店和物品底色都要读这张表，删了它们会一起失效）
$otherMods = Test-OtherMods

foreach ($rel in $ourRel) {
    $wasThereBefore = $false
    if ($backupDir) {
        $wasThereBefore = Test-Path -LiteralPath (Join-Path $backupDir $rel)
    }
    if ($wasThereBefore) { continue }   # 已还原，保留

    if ($ourShared -contains $rel) {
        if ($otherMods) {
            Say ('  · 保留共用文件（其它 MOD 还要用）：' + $rel)
            continue
        }
    }
    if (Remove-One $rel) { $changed++ }
}

if ($otherMods -and $ourShared.Count -gt 0) {
    $kept = @($ourShared | Where-Object { Test-Path -LiteralPath (Join-Path $game $_) })
    if ($kept.Count -gt 0) {
        Say ''
        Say '  说明：稀有度表 NightRaider_item_tiers.csv 被保留了，'
        Say '  因为你游戏里还有别的 MOD（物品商店 / 物品底色）需要读它。'
        Say '  如果你想彻底删掉，确认那些 MOD 也不用了之后，手动删除即可。'
    }
}

# ---------------------------------------------------------------- 结果
Line
if ($changed -eq 0) {
    Warn '  没找到需要卸载的内容（可能已经卸载过了）。'
}
else {
    Ok '  已卸载刷新商店。'
}

# 有没有别的 MOD 还在？
$leftPlugins = @(Get-ChildItem -LiteralPath (Join-Path $game 'BepInEx\plugins') -File -Filter '*.dll' -ErrorAction SilentlyContinue)
$loaderLeft = (Test-Path -LiteralPath (Join-Path $game 'winhttp.dll')) -or
              (Test-Path -LiteralPath (Join-Path $game 'BepInEx\core\BepInEx.dll'))

Say ''
if ($leftPlugins.Count -gt 0) {
    Ok ('  你还有 ' + $leftPlugins.Count + ' 个 MOD 插件保留着，它们没被动过：')
    foreach ($p in $leftPlugins) { Say ('      ' + $p.Name) }
    Say ''
    Say '  BepInEx 运行库也保留了 —— 这些 MOD 可以照常使用。'
}
elseif ($loaderLeft) {
    Say '  已没有其它 MOD 插件，但 BepInEx 运行库还在（不占多少空间，'
    Say '  留着方便你以后装别的 MOD）。想彻底清干净可以手动删除：'
    Say ('      ' + (Join-Path $game 'BepInEx'))
    Say ('      ' + (Join-Path $game 'winhttp.dll'))
    Say ('      ' + (Join-Path $game 'doorstop_config.ini'))
    Say ('      ' + (Join-Path $game '.doorstop_version'))
}
else {
    Ok '  游戏已恢复到没有 MOD 的状态。'
}

if ($backupDir -and (Test-Path -LiteralPath $backupDir)) {
    Say ''
    Say ('  备份仍保留在：' + $backupDir)
    Say '  确认游戏一切正常后，可以自己把它删掉。'
}

Say ''
Read-Host '  按回车关闭'
